package `in`.kusumbakeryjunction.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val KusumBakeryColorScheme = lightColorScheme(
    primary = BakeryChocolatePrimary,
    onPrimary = Color.White,
    primaryContainer = BakeryLatteCard,
    onPrimaryContainer = BakeryChocolateDark,
    secondary = BakeryCaramelSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE5C4),
    onSecondaryContainer = BakeryChocolateDark,
    tertiary = BakeryGoldAccent,
    background = BakeryCreamBg,
    onBackground = BakeryChocolateDark,
    surface = BakeryWarmSurface,
    onSurface = BakeryChocolateDark,
    surfaceVariant = BakeryLatteCard,
    onSurfaceVariant = BakeryCinnamonMuted,
    error = StatusErrorRed,
    onError = Color.White,
    outline = BakeryDivider
)

val KusumBakeryShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun KusumBakeryTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KusumBakeryColorScheme,
        typography = BakeryTypography,
        shapes = KusumBakeryShapes,
        content = content
    )
}
