package `in`.kusumbakeryjunction.app.ui.screens.owner

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.kusumbakeryjunction.app.data.model.*
import `in`.kusumbakeryjunction.app.ui.theme.*
import `in`.kusumbakeryjunction.app.util.BusinessLogicEngine
import `in`.kusumbakeryjunction.app.util.Formatters
import `in`.kusumbakeryjunction.app.util.QrCodeHelper
import `in`.kusumbakeryjunction.app.util.WhatsAppHelper
import `in`.kusumbakeryjunction.app.viewmodel.KusumUiState
import `in`.kusumbakeryjunction.app.viewmodel.KusumViewModel

private enum class OwnerTab(val title: String) {
    ANALYTICS("Dashboard"),
    MENU("Products"),
    QR_TABLES("QR Tables"),
    COMEBACK("21d Come-Back"),
    SETTINGS("Settings")
}

@Composable
fun OwnerAdminScreen(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    var selectedTab by remember { mutableStateOf(OwnerTab.ANALYTICS) }

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = BakeryWarmSurface) {
                OwnerTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {
                            val icon = when (tab) {
                                OwnerTab.ANALYTICS -> Icons.Default.Analytics
                                OwnerTab.MENU -> Icons.Default.RestaurantMenu
                                OwnerTab.QR_TABLES -> Icons.Default.QrCode2
                                OwnerTab.COMEBACK -> Icons.Default.Campaign
                                OwnerTab.SETTINGS -> Icons.Default.Settings
                            }
                            Icon(icon, contentDescription = tab.title)
                        },
                        label = { Text(tab.title, maxLines = 1) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BakeryCreamBg)
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                OwnerTab.ANALYTICS -> OwnerAnalyticsDashboardSection(uiState, viewModel)
                OwnerTab.MENU -> OwnerProductManagementSection(uiState, viewModel)
                OwnerTab.QR_TABLES -> OwnerQrTableManagementSection(uiState, viewModel)
                OwnerTab.COMEBACK -> OwnerComeBackOffersSection(uiState, viewModel)
                OwnerTab.SETTINGS -> OwnerAppSettingsSection(uiState, viewModel)
            }
        }
    }
}

// ============================================================================
// 1. Owner Analytics Dashboard (All 11 KPIs + 4 Date Filters)
// ============================================================================
@Composable
private fun OwnerAnalyticsDashboardSection(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    val metrics = remember(
        uiState.selectedDateFilter,
        uiState.orders,
        uiState.customers,
        uiState.offerHistory,
        uiState.rewards
    ) {
        BusinessLogicEngine.computeOwnerDashboardMetrics(
            filterRange = uiState.selectedDateFilter,
            customStartMillis = uiState.customStartDateMillis,
            customEndMillis = uiState.customEndDateMillis,
            orders = uiState.orders,
            customers = uiState.customers,
            offerHistory = uiState.offerHistory,
            rewards = uiState.rewards
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Owner Executive Dashboard (IST)",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DateFilterRange.values().toList()) { filter ->
                    FilterChip(
                        selected = uiState.selectedDateFilter == filter,
                        onClick = { viewModel.setDateFilter(filter) },
                        label = { Text(filter.label) }
                    )
                }
            }
        }

        // KPI Grid Rows
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiCard("Today's Orders", "${metrics.todayOrdersCount}", Modifier.weight(1f))
                KpiCard("Today's Sales", Formatters.formatInr(metrics.todaySalesInr), Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiCard("Monthly Sales (30d)", Formatters.formatInr(metrics.monthlySalesInr), Modifier.weight(1f))
                KpiCard("Pending Orders", "${metrics.pendingOrdersCount}", Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiCard("Total Customers", "${metrics.totalCustomersCount}", Modifier.weight(1f))
                KpiCard("New Customers", "${metrics.newCustomersCount}", Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiCard("Repeat Customer %", "${metrics.repeatCustomerPercentage}%", Modifier.weight(1f))
                KpiCard("Rewards Redeemed", "${metrics.loyaltyRewardsRedeemedCount}", Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiCard("Offers Sent", "${metrics.offersSentCount}", Modifier.weight(1f))
                KpiCard("Returned After Offer", "${metrics.customersReturnedAfterOfferCount}", Modifier.weight(1f))
            }
        }

        // Top Selling Products Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Top-Selling Bakery Products (${uiState.selectedDateFilter.label})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (metrics.topSellingProducts.isEmpty()) {
                        Text("No completed product sales in this date window yet.")
                    } else {
                        metrics.topSellingProducts.forEachIndexed { idx, (prodName, qty) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${idx + 1}. $prodName", modifier = Modifier.weight(1f))
                                Text("$qty sold", fontWeight = FontWeight.Bold, color = BakeryChocolatePrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    color = BakeryChocolatePrimary,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

// ============================================================================
// 2. Owner Product & Menu Management (Add, Edit, Price ₹, Discount, Availability, Delete)
// ============================================================================
@Composable
private fun OwnerProductManagementSection(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    var editingProductId by remember { mutableStateOf<String?>(null) }
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priceInr by remember { mutableStateOf("") }
    var discountPct by remember { mutableStateOf("0") }
    var imageUrl by remember { mutableStateOf("") }
    var selectedCatId by remember { mutableStateOf(uiState.categories.firstOrNull()?.id ?: "cat_cakes") }
    var isDemoData by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (editingProductId == null) "Add New Bakery Product" else "Edit Product ($editingProductId)",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Product Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = priceInr,
                            onValueChange = { priceInr = it },
                            label = { Text("Price in ₹") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = discountPct,
                            onValueChange = { discountPct = it },
                            label = { Text("Discount %") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = imageUrl,
                        onValueChange = { imageUrl = it },
                        label = { Text("Product Image URL (Firebase Storage)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.saveProduct(
                                    existingId = editingProductId,
                                    name = name,
                                    description = description,
                                    categoryId = selectedCatId,
                                    priceInrText = priceInr,
                                    discountPercentText = discountPct,
                                    imageUrl = imageUrl,
                                    isAvailable = true,
                                    isDemoData = isDemoData
                                )
                                editingProductId = null
                                name = ""
                                description = ""
                                priceInr = ""
                                discountPct = "0"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                        ) {
                            Text(if (editingProductId == null) "Save Product" else "Update Product")
                        }
                        if (editingProductId != null) {
                            OutlinedButton(onClick = {
                                editingProductId = null
                                name = ""
                                description = ""
                                priceInr = ""
                            }) {
                                Text("Cancel Edit")
                            }
                        }
                    }
                }
            }
        }

        items(uiState.products, key = { it.id }) { prod ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(prod.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(Formatters.formatInr(prod.effectivePriceInr), fontWeight = FontWeight.Bold)
                    }
                    Text(prod.description, style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            editingProductId = prod.id
                            name = prod.name
                            description = prod.description
                            priceInr = prod.priceInr.toInt().toString()
                            discountPct = prod.discountPercent.toString()
                            imageUrl = prod.imageUrl
                            selectedCatId = prod.categoryId
                        }) {
                            Text("Edit")
                        }
                        OutlinedButton(onClick = { viewModel.toggleProductAvailability(prod) }) {
                            Text(if (prod.isAvailable) "Mark Sold Out" else "Mark Available")
                        }
                        OutlinedButton(
                            onClick = { viewModel.deleteProduct(prod.id) },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusErrorRed)
                        ) {
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// 3. Owner QR Code Management (Generate, Preview & Download/Print Table QRs)
// ============================================================================
@Composable
private fun OwnerQrTableManagementSection(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    val context = LocalContext.current
    var tableNumberText by remember { mutableStateOf("9") }
    var tableLabelText by remember { mutableStateOf("VIP Lounge Table") }
    var seatsText by remember { mutableStateOf("4") }
    var previewTable by remember { mutableStateOf<BakeryTable?>(uiState.tables.firstOrNull()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Generate New Table QR Code", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = tableNumberText,
                            onValueChange = { tableNumberText = it },
                            label = { Text("Table #") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = seatsText,
                            onValueChange = { seatsText = it },
                            label = { Text("Seats") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tableLabelText,
                        onValueChange = { tableLabelText = it },
                        label = { Text("Table Zone / Label") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val num = tableNumberText.toIntOrNull() ?: 9
                            val seats = seatsText.toIntOrNull() ?: 4
                            viewModel.addOrUpdateTableQr(num, tableLabelText, seats)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generate Table QR")
                    }
                }
            }
        }

        // Visual Printable QR Preview
        previewTable?.let { tbl ->
            item {
                val qrBitmap = remember(tbl.id, tbl.tableNumber) {
                    QrCodeHelper.generatePrintableQrBitmap(tbl.tableNumber, tbl.id, 420)
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = BakeryLatteCard),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Printable Standee Preview: ${tbl.id}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "QR Code for ${tbl.id}",
                            modifier = Modifier.size(220.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(tbl.qrPayload, style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { QrCodeHelper.shareOrPrintQrBitmap(context, tbl.tableNumber, tbl.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolateDark)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Download / Print QR Standee")
                        }
                    }
                }
            }
        }

        items(uiState.tables, key = { it.id }) { tbl ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${tbl.id} • ${tbl.label} (${tbl.seats} Seats)", fontWeight = FontWeight.Bold)
                        Text(tbl.qrPayload, style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = { previewTable = tbl }) {
                        Text("View / Print QR")
                    }
                }
            }
        }
    }
}

// ============================================================================
// 4. Come-Back Offers (Identify >=21 Days Inactive Customers & Individual WhatsApp Deep-Link)
// ============================================================================
@Composable
private fun OwnerComeBackOffersSection(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    val context = LocalContext.current
    val thresholdDays = uiState.appSettings.comebackThresholdDays
    val inactiveCustomers = remember(uiState.customers, thresholdDays) {
        BusinessLogicEngine.findComeBackCustomers(uiState.customers, thresholdDays, onlyOptedIn = false)
    }
    var selectedOffer by remember(uiState.offers) {
        mutableStateOf(uiState.offers.firstOrNull() ?: DemoSeedData.defaultOffers().first())
    }
    var newOfferTitle by remember { mutableStateOf("") }
    var newOfferCode by remember { mutableStateOf("") }
    var newOfferDiscount by remember { mutableStateOf("20") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BakeryLatteCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Come-Back Offer Compliance Policy",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "• Automatically identifies customers inactive for >= $thresholdDays days.
" +
                            "• Individual WhatsApp offers are ONLY enabled for customers with Marketing Consent = TRUE.
" +
                            "• Bulk automated WhatsApp messaging is disabled unless official WhatsApp Business Cloud API credentials are configured.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Create New Offer Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Create Come-Back Promotional Offer", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newOfferTitle,
                        onValueChange = { newOfferTitle = it },
                        label = { Text("Offer Headline") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newOfferCode,
                            onValueChange = { newOfferCode = it },
                            label = { Text("Promo Code") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = newOfferDiscount,
                            onValueChange = { newOfferDiscount = it },
                            label = { Text("Discount %") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            viewModel.createPromotionalOffer(
                                title = newOfferTitle,
                                description = "Special Come-Back Offer for Kusum Bakery Junction guests!",
                                promoCode = newOfferCode,
                                discountPercent = newOfferDiscount.toIntOrNull() ?: 20,
                                maxDiscountInr = 150.0
                            )
                            newOfferTitle = ""
                            newOfferCode = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                    ) {
                        Text("Create Offer")
                    }
                }
            }
        }

        item {
            Text(
                text = "Customers Inactive >= $thresholdDays Days (${inactiveCustomers.size})",
                style = MaterialTheme.typography.titleLarge
            )
        }

        items(inactiveCustomers, key = { it.uid }) { cust ->
            val daysAbsent = Formatters.daysSinceIst(cust.lastVisitAt)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(cust.name, fontWeight = FontWeight.Bold)
                        Text(
                            text = "$daysAbsent days since last visit",
                            color = StatusErrorRed,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Text("Phone: ${cust.phone} • Last Visit: ${Formatters.formatIstDate(cust.lastVisitAt)}")
                    Text(
                        text = if (cust.marketingConsent) "✅ Marketing Opt-In Verified" else "🚫 Opted Out of Marketing (Contact Blocked)",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (cust.marketingConsent) StatusCompletedText else StatusErrorRed
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val launched = WhatsAppHelper.launchIndividualWhatsAppOffer(
                                context = context,
                                customer = cust,
                                offer = selectedOffer,
                                onError = {}
                            )
                            if (launched || cust.marketingConsent) {
                                viewModel.recordIndividualWhatsAppComeBackOffer(cust, selectedOffer)
                            }
                        },
                        enabled = cust.marketingConsent,
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (cust.marketingConsent) "Send Individual WhatsApp (${selectedOffer.promoCode})"
                            else "Blocked (No Marketing Consent)",
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Offer Delivery & Redemption History
        if (uiState.offerHistory.isNotEmpty()) {
            item {
                Text("Sent Offer Delivery & Return Tracking", style = MaterialTheme.typography.titleLarge)
            }
            items(uiState.offerHistory, key = { it.id }) { hist ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${hist.customerName} • Code: ${hist.promoCode}", fontWeight = FontWeight.Bold)
                            Text(
                                "Status: ${hist.deliveryStatus} • Sent ${Formatters.formatIstDateTime(hist.sentAt)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (!hist.customerReturned) {
                            OutlinedButton(onClick = { viewModel.markOfferCustomerReturned(hist.id) }) {
                                Text("Mark Returned")
                            }
                        } else {
                            Text("Returned ✅", color = StatusCompletedText, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// 5. Editable Business & App Settings (Owner Only)
// ============================================================================
@Composable
private fun OwnerAppSettingsSection(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    var rewardTitle by remember(uiState.appSettings.freeRewardTitle) {
        mutableStateOf(uiState.appSettings.freeRewardTitle)
    }
    var reviewUrl by remember(uiState.appSettings.googleReviewUrl) {
        mutableStateOf(uiState.appSettings.googleReviewUrl)
    }
    var thresholdDaysText by remember(uiState.appSettings.comebackThresholdDays) {
        mutableStateOf(uiState.appSettings.comebackThresholdDays.toString())
    }
    var whatsAppApiEnabled by remember(uiState.appSettings.whatsAppBusinessApiEnabled) {
        mutableStateOf(uiState.appSettings.whatsAppBusinessApiEnabled)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Configurable Bakery Settings (Owner Only)", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = rewardTitle,
                        onValueChange = { rewardTitle = it },
                        label = { Text("5-Stamp Free Reward Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = reviewUrl,
                        onValueChange = { reviewUrl = it },
                        label = { Text("Google Business Profile Review URL") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = thresholdDaysText,
                        onValueChange = { thresholdDaysText = it },
                        label = { Text("Come-Back Inactivity Threshold (Days)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("WhatsApp Business Cloud API Hook", fontWeight = FontWeight.Bold)
                            Text(
                                "Enable future approved WhatsApp Business API template integration.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = whatsAppApiEnabled,
                            onCheckedChange = { whatsAppApiEnabled = it }
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            viewModel.updateAppSettings(
                                freeRewardTitle = rewardTitle,
                                googleReviewUrl = reviewUrl,
                                comebackThresholdDays = thresholdDaysText.toIntOrNull() ?: 21,
                                whatsAppApiEnabled = whatsAppApiEnabled
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Business Settings to Firestore")
                    }
                }
            }
        }
    }
}
