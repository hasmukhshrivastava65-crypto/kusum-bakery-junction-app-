package `in`.kusumbakeryjunction.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BakeryDining
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.kusumbakeryjunction.app.data.model.AppUser
import `in`.kusumbakeryjunction.app.data.model.OrderStatus
import `in`.kusumbakeryjunction.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KusumTopAppBar(
    currentUser: AppUser?,
    onLogout: () -> Unit
) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Temporary Replaceable Brand Logo Placeholder
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(BakeryGoldAccent)
                        .border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.BakeryDining,
                        contentDescription = "Kusum Bakery Junction Temporary Logo Placeholder",
                        tint = BakeryChocolateDark,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Kusum Bakery Junction",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentUser?.let { "${it.name} • ${it.role.name}" }
                            ?: "Artisan Bakery & Cafe • Bhopal (IST)",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFFFE5C4),
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        actions = {
            if (currentUser != null) {
                IconButton(onClick = onLogout) {
                    Icon(
                        imageVector = Icons.Default.Logout,
                        contentDescription = "Sign Out",
                        tint = Color.White
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = BakeryChocolateDark
        )
    )
}

@Composable
fun DemoDataDisclosureBanner() {
    Surface(
        color = Color(0xFFFFF3CD),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = Color(0xFF856404),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "DEMO DATA NOTICE: Sample menu items & prices (₹) are marked [DEMO DATA] and are fully editable in Owner Admin.",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color(0xFF856404),
                    fontWeight = FontWeight.Medium
                )
            )
        }
    }
}

@Composable
fun FeedbackBanner(
    statusMessage: String?,
    errorMessage: String?,
    onDismiss: () -> Unit
) {
    if (errorMessage != null) {
        Surface(
            color = Color(0xFFFDECEA),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = StatusErrorRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = errorMessage,
                    color = StatusErrorRed,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = StatusErrorRed)
                }
            }
        }
    } else if (statusMessage != null) {
        Surface(
            color = Color(0xFFE8F5E9),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusCompletedText)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = statusMessage,
                    color = StatusCompletedText,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = StatusCompletedText)
                }
            }
        }
    }
}

@Composable
fun OrderStatusBadge(status: OrderStatus) {
    val (bg, fg) = when (status) {
        OrderStatus.PENDING -> StatusPendingBg to StatusPendingText
        OrderStatus.ACCEPTED -> StatusAcceptedBg to StatusAcceptedText
        OrderStatus.PREPARING -> StatusPreparingBg to StatusPreparingText
        OrderStatus.READY -> StatusReadyBg to StatusReadyText
        OrderStatus.COMPLETED -> StatusCompletedBg to StatusCompletedText
        OrderStatus.CANCELLED -> Color(0xFFF8D7DA) to StatusErrorRed
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(50),
        modifier = Modifier.padding(2.dp)
    ) {
        Text(
            text = status.displayName.uppercase(),
            color = fg,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
