package `in`.kusumbakeryjunction.app.ui.screens.staff

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.kusumbakeryjunction.app.data.model.OrderStatus
import `in`.kusumbakeryjunction.app.ui.components.OrderStatusBadge
import `in`.kusumbakeryjunction.app.ui.theme.*
import `in`.kusumbakeryjunction.app.util.Formatters
import `in`.kusumbakeryjunction.app.viewmodel.KusumUiState
import `in`.kusumbakeryjunction.app.viewmodel.KusumViewModel

@Composable
fun StaffDashboardScreen(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    var selectedSection by remember { mutableIntStateOf(0) }
    var rewardCodeInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BakeryCreamBg)
    ) {
        // Security Notice Banner confirming Staff cannot access Owner financials
        Surface(
            color = BakeryLatteCard,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = BakeryChocolatePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "STAFF PORTAL: Authorized for Live Orders, 1-Tap Stamps & Reward Redemption. Owner financial reports & settings are restricted.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        TabRow(selectedTabIndex = selectedSection, containerColor = BakeryWarmSurface) {
            Tab(
                selected = selectedSection == 0,
                onClick = { selectedSection = 0 },
                text = { Text("Today's Orders (${uiState.orders.size})") }
            )
            Tab(
                selected = selectedSection == 1,
                onClick = { selectedSection = 1 },
                text = { Text("Customer Lookup & 1-Tap Stamp") }
            )
        }

        if (selectedSection == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(uiState.orders, key = { it.id }) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${order.id} • Table #${order.tableNumber}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                OrderStatusBadge(order.status)
                            }
                            Text(
                                text = "Customer: ${order.customerName} (${order.customerPhone})",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            order.itemsSummary.forEach { item ->
                                Text("• ${item.quantity}x ${item.productName}")
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            // Workflow Action Buttons: Pending -> Accepted -> Preparing -> Ready -> Completed
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                when (order.status) {
                                    OrderStatus.PENDING -> {
                                        Button(onClick = { viewModel.advanceOrderStatus(order, OrderStatus.ACCEPTED) }) {
                                            Text("Accept Order")
                                        }
                                    }
                                    OrderStatus.ACCEPTED -> {
                                        Button(onClick = { viewModel.advanceOrderStatus(order, OrderStatus.PREPARING) }) {
                                            Text("Mark Preparing")
                                        }
                                    }
                                    OrderStatus.PREPARING -> {
                                        Button(onClick = { viewModel.advanceOrderStatus(order, OrderStatus.READY) }) {
                                            Text("Mark Ready")
                                        }
                                    }
                                    OrderStatus.READY -> {
                                        Button(onClick = { viewModel.advanceOrderStatus(order, OrderStatus.COMPLETED) }) {
                                            Text("Complete Order")
                                        }
                                    }
                                    OrderStatus.COMPLETED -> {
                                        val cust = uiState.customers.find { it.uid == order.customerId }
                                        if (cust != null && !order.stampAwarded) {
                                            OutlinedButton(
                                                onClick = { viewModel.addOneTapLoyaltyStamp(cust, order.id) }
                                            ) {
                                                Icon(Icons.Default.Stars, contentDescription = null)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("1-Tap Add Loyalty Stamp")
                                            }
                                        } else {
                                            Text(
                                                text = "Order Completed • Stamp Awarded",
                                                color = StatusCompletedText,
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                    OrderStatus.CANCELLED -> {}
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Customer Search by Phone + 1-Tap Stamp + Reward Code Redemption
            val matchingCustomers = remember(uiState.customers, uiState.staffSearchPhoneQuery) {
                val q = uiState.staffSearchPhoneQuery.trim()
                if (q.isEmpty()) uiState.customers
                else uiState.customers.filter {
                    it.phone.contains(q, ignoreCase = true) || it.name.contains(q, ignoreCase = true)
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Redeem Customer Reward Code", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = rewardCodeInput,
                                    onValueChange = { rewardCodeInput = it },
                                    label = { Text("Reward Code (e.g. KBJ-RWD-AARAV5)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                Button(
                                    onClick = { viewModel.redeemCustomerRewardCode(rewardCodeInput) },
                                    colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                                ) {
                                    Text("Redeem")
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = uiState.staffSearchPhoneQuery,
                        onValueChange = { viewModel.updateStaffSearchPhone(it) },
                        label = { Text("Search Customer by Phone Number or Name") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                items(matchingCustomers, key = { it.uid }) { cust ->
                    val card = uiState.loyaltyCards[cust.uid]
                    val currentStamps = card?.currentStamps ?: cust.loyaltyStamps
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(cust.name, fontWeight = FontWeight.Bold)
                                Text("Phone: ${cust.phone}", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    "Visits: ${cust.totalVisits} • Current Stamps: $currentStamps / 5",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    "Last Visit: ${Formatters.formatIstDate(cust.lastVisitAt)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Button(
                                onClick = { viewModel.addOneTapLoyaltyStamp(cust) },
                                colors = ButtonDefaults.buttonColors(containerColor = BakeryCaramelSecondary)
                            ) {
                                Icon(Icons.Default.AddCircle, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("+1 Stamp")
                            }
                        }
                    }
                }
            }
        }
    }
}
