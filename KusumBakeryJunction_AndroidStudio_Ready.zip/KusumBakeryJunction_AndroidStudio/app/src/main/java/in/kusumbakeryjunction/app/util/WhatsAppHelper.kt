package `in`.kusumbakeryjunction.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import `in`.kusumbakeryjunction.app.data.model.AppUser
import `in`.kusumbakeryjunction.app.data.model.PromotionalOffer
import java.net.URLEncoder

object WhatsAppHelper {

    /**
     * Composes a personalized Come-Back Offer message for an opted-in customer
     * who hasn't visited Kusum Bakery Junction in >= 21 days.
     */
    fun buildComeBackMessage(customer: AppUser, offer: PromotionalOffer): String {
        val daysAbsent = Formatters.daysSinceIst(customer.lastVisitAt)
        return buildString {
            append("Namaste ${customer.name}! 🙏\n\n")
            append("We've missed seeing you at *Kusum Bakery Junction* over the last $daysAbsent days! 🥐☕\n\n")
            append("🎁 *Special Come-Back Offer for You:*\n")
            append("*${offer.title}* — ${offer.description}\n")
            if (offer.discountPercent > 0) {
                append("✨ Flat *${offer.discountPercent}% OFF* (Up to ₹${offer.maxDiscountInr.toInt()})\n")
            }
            append("🏷️ Use Promo Code: *${offer.promoCode}* on your next visit!\n\n")
            append("Reply STOP anytime to opt out of promotional messages.")
        }
    }

    /**
     * Launches an individual WhatsApp message intent ONLY if the customer has
     * explicitly opted in to marketing messages (marketingConsent == true).
     * Never sends bulk automated messages without approved WhatsApp Business API integration.
     */
    fun launchIndividualWhatsAppOffer(
        context: Context,
        customer: AppUser,
        offer: PromotionalOffer,
        onError: (String) -> Unit
    ): Boolean {
        if (!customer.marketingConsent) {
            onError("Blocked: ${customer.name} has not opted in to marketing messages.")
            return false
        }
        val cleanDigits = customer.phone.filter { it.isDigit() }
        val intlPhone = if (cleanDigits.startsWith("91") && cleanDigits.length == 12) {
            cleanDigits
        } else {
            "91${cleanDigits.takeLast(10)}"
        }
        val message = buildComeBackMessage(customer, offer)
        return try {
            val encoded = URLEncoder.encode(message, "UTF-8")
            val uri = Uri.parse("https://wa.me/$intlPhone?text=$encoded")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            onError("Could not open WhatsApp on this device: ${e.localizedMessage}")
            false
        }
    }
}
