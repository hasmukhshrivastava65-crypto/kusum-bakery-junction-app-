package `in`.kusumbakeryjunction.app.data.repository

import android.app.Activity
import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import `in`.kusumbakeryjunction.app.data.model.*
import `in`.kusumbakeryjunction.app.util.Formatters
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID
import java.util.concurrent.TimeUnit

class FirebaseBakeryRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {

    // Firestore Collection Names (All 12 Required Collections)
    companion object {
        const val COL_USERS = "users"
        const val COL_PRODUCTS = "products"
        const val COL_CATEGORIES = "categories"
        const val COL_ORDERS = "orders"
        const val COL_ORDER_ITEMS = "orderItems"
        const val COL_LOYALTY_CARDS = "loyaltyCards"
        const val COL_STAMP_HISTORY = "stampHistory"
        const val COL_REWARDS = "rewards"
        const val COL_OFFERS = "offers"
        const val COL_OFFER_HISTORY = "offerHistory"
        const val COL_TABLES = "tables"
        const val COL_APP_SETTINGS = "appSettings"
    }

    // =========================================================================
    // 1. Authentication & Role-Based Profile Resolution
    // =========================================================================

    fun currentFirebaseUid(): String? = auth.currentUser?.uid

    suspend fun fetchUserProfile(uid: String): Result<AppUser> = runCatching {
        val snap = db.collection(COL_USERS).document(uid).get().await()
        if (snap.exists()) {
            snap.toObject(AppUser::class.java)?.copy(uid = uid)
                ?: throw IllegalStateException("Invalid user profile document.")
        } else {
            throw NoSuchElementException("User profile not found for uid=$uid")
        }
    }

    suspend fun registerCustomerWithEmailOrPhone(
        name: String,
        phone: String,
        email: String,
        password: String,
        marketingConsent: Boolean
    ): Result<AppUser> = runCatching {
        require(name.trim().length >= 2) { "Please enter your full name." }
        require(Formatters.isValidIndianPhone(phone)) { "Enter a valid 10-digit Indian mobile number." }

        val normalizedPhone = Formatters.normalizeIndianPhone(phone)
        val effectiveEmail = email.ifBlank { "${normalizedPhone.removePrefix("+")}@kusumbakery.in" }
        val authResult = auth.createUserWithEmailAndPassword(effectiveEmail, password).await()
        val uid = authResult.user?.uid ?: throw IllegalStateException("Authentication failed.")

        val newUser = AppUser(
            uid = uid,
            name = name.trim(),
            phone = normalizedPhone,
            email = effectiveEmail,
            role = UserRole.CUSTOMER,
            totalVisits = 1,
            lastVisitAt = System.currentTimeMillis(),
            loyaltyStamps = 0,
            marketingConsent = marketingConsent,
            isActive = true,
            isDemoData = false
        )

        val initialLoyalty = LoyaltyCard(
            customerId = uid,
            customerName = newUser.name,
            customerPhone = newUser.phone,
            currentStamps = 0,
            totalStampsEarned = 0,
            totalRewardsUnlocked = 0
        )

        db.runBatch { batch ->
            batch.set(db.collection(COL_USERS).document(uid), newUser)
            batch.set(db.collection(COL_LOYALTY_CARDS).document(uid), initialLoyalty)
        }.await()

        newUser
    }

    suspend fun signInWithEmailPassword(emailOrPhone: String, password: String): Result<AppUser> = runCatching {
        val loginEmail = if (emailOrPhone.contains("@")) {
            emailOrPhone.trim()
        } else {
            val normalized = Formatters.normalizeIndianPhone(emailOrPhone)
            "${normalized.removePrefix("+")}@kusumbakery.in"
        }
        val res = auth.signInWithEmailAndPassword(loginEmail, password).await()
        val uid = res.user?.uid ?: throw IllegalStateException("Login failed.")
        fetchUserProfile(uid).getOrThrow()
    }

    suspend fun signInWithGoogleIdToken(idToken: String): Result<AppUser> = runCatching {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        val res = auth.signInWithCredential(credential).await()
        val fbUser = res.user ?: throw IllegalStateException("Google Sign-In failed.")
        val existing = db.collection(COL_USERS).document(fbUser.uid).get().await()
        if (existing.exists()) {
            existing.toObject(AppUser::class.java)!!.copy(uid = fbUser.uid)
        } else {
            val newUser = AppUser(
                uid = fbUser.uid,
                name = fbUser.displayName ?: "Bakery Guest",
                phone = fbUser.phoneNumber ?: "",
                email = fbUser.email ?: "",
                role = UserRole.CUSTOMER,
                totalVisits = 1,
                lastVisitAt = System.currentTimeMillis(),
                loyaltyStamps = 0,
                marketingConsent = true
            )
            db.collection(COL_USERS).document(fbUser.uid).set(newUser).await()
            db.collection(COL_LOYALTY_CARDS).document(fbUser.uid).set(
                LoyaltyCard(
                    customerId = fbUser.uid,
                    customerName = newUser.name,
                    customerPhone = newUser.phone
                )
            ).await()
            newUser
        }
    }

    fun startPhoneNumberOtpVerification(
        activity: Activity,
        rawPhone: String,
        callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ) {
        val normalized = Formatters.normalizeIndianPhone(rawPhone)
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(normalized)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    suspend fun signInWithPhoneOtpCredential(
        credential: PhoneAuthCredential,
        customerNameIfNew: String,
        rawPhone: String
    ): Result<AppUser> = runCatching {
        val res = auth.signInWithCredential(credential).await()
        val fbUser = res.user ?: throw IllegalStateException("OTP verification failed.")
        val docRef = db.collection(COL_USERS).document(fbUser.uid)
        val snap = docRef.get().await()
        if (snap.exists()) {
            snap.toObject(AppUser::class.java)!!.copy(uid = fbUser.uid)
        } else {
            val normalizedPhone = Formatters.normalizeIndianPhone(rawPhone)
            val newUser = AppUser(
                uid = fbUser.uid,
                name = customerNameIfNew.ifBlank { "Bakery Guest" },
                phone = normalizedPhone,
                role = UserRole.CUSTOMER,
                totalVisits = 1,
                lastVisitAt = System.currentTimeMillis()
            )
            docRef.set(newUser).await()
            db.collection(COL_LOYALTY_CARDS).document(fbUser.uid).set(
                LoyaltyCard(
                    customerId = fbUser.uid,
                    customerName = newUser.name,
                    customerPhone = newUser.phone
                )
            ).await()
            newUser
        }
    }

    fun signOut() {
        auth.signOut()
    }

    // =========================================================================
    // 2. Real-Time Streams (Products, Categories, Orders, Loyalty, Rewards, Settings)
    // =========================================================================

    fun observeProducts(): Flow<List<BakeryProduct>> = callbackFlow {
        val listener = db.collection(COL_PRODUCTS)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(BakeryProduct::class.java)?.copy(id = doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeCategories(): Flow<List<BakeryCategory>> = callbackFlow {
        val listener = db.collection(COL_CATEGORIES)
            .orderBy("displayOrder", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(BakeryCategory::class.java)?.copy(id = doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeTables(): Flow<List<BakeryTable>> = callbackFlow {
        val listener = db.collection(COL_TABLES)
            .orderBy("tableNumber", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(BakeryTable::class.java)?.copy(id = doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeAllOrders(): Flow<List<BakeryOrder>> = callbackFlow {
        val listener = db.collection(COL_ORDERS)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(BakeryOrder::class.java)?.copy(id = doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeCustomerOrders(customerId: String): Flow<List<BakeryOrder>> = callbackFlow {
        val listener = db.collection(COL_ORDERS)
            .whereEqualTo("customerId", customerId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(BakeryOrder::class.java)?.copy(id = doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeLoyaltyCard(customerId: String): Flow<LoyaltyCard?> = callbackFlow {
        val listener = db.collection(COL_LOYALTY_CARDS).document(customerId)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                trySend(snap?.toObject(LoyaltyCard::class.java))
            }
        awaitClose { listener.remove() }
    }

    fun observeStampHistory(customerId: String): Flow<List<StampHistoryRecord>> = callbackFlow {
        val listener = db.collection(COL_STAMP_HISTORY)
            .whereEqualTo("customerId", customerId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(StampHistoryRecord::class.java)?.copy(id = doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeRewards(customerId: String? = null): Flow<List<CustomerReward>> = callbackFlow {
        val query = if (customerId != null) {
            db.collection(COL_REWARDS).whereEqualTo("customerId", customerId)
        } else {
            db.collection(COL_REWARDS)
        }
        val listener = query.addSnapshotListener { snap, err ->
            if (err != null) return@addSnapshotListener
            val list = snap?.documents?.mapNotNull { doc ->
                doc.toObject(CustomerReward::class.java)?.copy(id = doc.id)
            }.orEmpty().sortedByDescending { it.unlockedAt }
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    fun observeOffers(): Flow<List<PromotionalOffer>> = callbackFlow {
        val listener = db.collection(COL_OFFERS)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(PromotionalOffer::class.java)?.copy(id = doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeOfferHistory(): Flow<List<OfferDeliveryRecord>> = callbackFlow {
        val listener = db.collection(COL_OFFER_HISTORY)
            .orderBy("sentAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(OfferDeliveryRecord::class.java)?.copy(id = doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun observeAppSettings(): Flow<BakeryAppSettings> = callbackFlow {
        val listener = db.collection(COL_APP_SETTINGS).document("global_config")
            .addSnapshotListener { snap, err ->
                if (err != null) return@addSnapshotListener
                trySend(snap?.toObject(BakeryAppSettings::class.java) ?: BakeryAppSettings())
            }
        awaitClose { listener.remove() }
    }

    // =========================================================================
    // 3. QR Table Ordering & Order Status Workflow
    // =========================================================================

    suspend fun validateAndPlaceTableOrder(
        customerId: String,
        customerName: String,
        customerPhone: String,
        tableId: String,
        cartItems: List<CartItem>,
        availableTables: List<BakeryTable>
    ): Result<BakeryOrder> = runCatching {
        require(customerName.trim().length >= 2) { "Customer name is required." }
        require(Formatters.isValidIndianPhone(customerPhone)) { "Enter a valid 10-digit Indian mobile number." }
        require(cartItems.isNotEmpty()) { "Your cart is empty. Add bakery items before ordering." }

        val validTable = availableTables.find {
            it.id.equals(tableId.trim(), ignoreCase = true) && it.isActive
        } ?: throw IllegalArgumentException("Invalid or inactive Table QR Code ($tableId). Please scan a valid table QR.")

        val orderId = Formatters.generateOrderId()
        val now = System.currentTimeMillis()
        val normalizedPhone = Formatters.normalizeIndianPhone(customerPhone)

        val rawSubtotal = cartItems.sumOf { it.product.priceInr * it.quantity }
        val effectiveTotal = cartItems.sumOf { it.lineTotalInr }
        val totalDiscount = (rawSubtotal - effectiveTotal).coerceAtLeast(0.0)

        val itemRecords = cartItems.mapIndexed { idx, cartItem ->
            OrderItemRecord(
                id = "${orderId}_ITEM_${idx + 1}",
                orderId = orderId,
                customerId = customerId,
                productId = cartItem.product.id,
                productName = cartItem.product.name,
                quantity = cartItem.quantity,
                unitPriceInr = cartItem.product.effectivePriceInr,
                totalPriceInr = cartItem.lineTotalInr,
                createdAt = now
            )
        }

        val order = BakeryOrder(
            id = orderId,
            customerId = customerId,
            customerName = customerName.trim(),
            customerPhone = normalizedPhone,
            tableId = validTable.id,
            tableNumber = validTable.tableNumber,
            itemsSummary = itemRecords,
            subtotalInr = rawSubtotal,
            discountInr = totalDiscount,
            totalAmount = effectiveTotal,
            status = OrderStatus.PENDING,
            stampAwarded = false,
            isDemoData = false,
            createdAt = now,
            updatedAt = now
        )

        db.runBatch { batch ->
            batch.set(db.collection(COL_ORDERS).document(orderId), order)
            itemRecords.forEach { record ->
                batch.set(db.collection(COL_ORDER_ITEMS).document(record.id), record)
            }
            batch.set(
                db.collection(COL_USERS).document(customerId),
                mapOf(
                    "lastVisitAt" to now,
                    "updatedAt" to now
                ),
                SetOptions.merge()
            )
        }.await()

        order
    }

    suspend fun updateOrderStatus(
        orderId: String,
        newStatus: OrderStatus,
        actorRole: UserRole
    ): Result<Unit> = runCatching {
        require(actorRole == UserRole.STAFF || actorRole == UserRole.OWNER) {
            "Unauthorized: Only Staff or Owner can update order statuses."
        }
        val now = System.currentTimeMillis()
        db.collection(COL_ORDERS).document(orderId)
            .update(
                mapOf(
                    "status" to newStatus.name,
                    "updatedAt" to now
                )
            ).await()
    }

    // =========================================================================
    // 4. Five-Slot Loyalty Stamp Card & Anti-Duplicate Reward Redemption
    // =========================================================================

    /**
     * Atomically adds 1 loyalty stamp to a customer's 5-slot card.
     * - Prevents duplicate stamps for the same orderId.
     * - Automatically unlocks a unique Reward Code (KBJ-RWD-XXXXXX) when reaching 5 stamps
     *   and resets the 5-slot counter to 0 for the next cycle while keeping full stamp history.
     */
    suspend fun addLoyaltyStampAtomic(
        customer: AppUser,
        orderId: String,
        staffUser: AppUser,
        settings: BakeryAppSettings
    ): Result<Pair<LoyaltyCard, CustomerReward?>> = runCatching {
        require(staffUser.role == UserRole.STAFF || staffUser.role == UserRole.OWNER) {
            "Unauthorized: Only Staff or Owner can add loyalty stamps."
        }

        val cardRef = db.collection(COL_LOYALTY_CARDS).document(customer.uid)
        val userRef = db.collection(COL_USERS).document(customer.uid)
        val stampDocId = if (orderId.isNotBlank()) "STAMP_${customer.uid}_$orderId" else UUID.randomUUID().toString()
        val stampRef = db.collection(COL_STAMP_HISTORY).document(stampDocId)

        var updatedCard = LoyaltyCard()
        var newlyUnlockedReward: CustomerReward? = null

        db.runTransaction { tx ->
            val existingStamp = tx.get(stampRef)
            if (existingStamp.exists()) {
                throw IllegalStateException("Duplicate prevented: Stamp already awarded for Order $orderId.")
            }

            val cardSnap = tx.get(cardRef)
            val currentCard = cardSnap.toObject(LoyaltyCard::class.java) ?: LoyaltyCard(
                customerId = customer.uid,
                customerName = customer.name,
                customerPhone = customer.phone
            )

            if (orderId.isNotBlank() && currentCard.lastStampOrderId == orderId) {
                throw IllegalStateException("Duplicate prevented: Order $orderId already earned a stamp.")
            }

            val now = System.currentTimeMillis()
            val nextStamps = currentCard.currentStamps + 1
            val reachedFive = nextStamps >= settings.loyaltyStampsRequired

            val finalCycleStamps = if (reachedFive) 0 else nextStamps
            val unlockedCount = if (reachedFive) currentCard.totalRewardsUnlocked + 1 else currentCard.totalRewardsUnlocked

            updatedCard = currentCard.copy(
                currentStamps = finalCycleStamps,
                totalStampsEarned = currentCard.totalStampsEarned + 1,
                totalRewardsUnlocked = unlockedCount,
                lastStampOrderId = orderId.ifBlank { currentCard.lastStampOrderId },
                updatedAt = now
            )

            val historyRecord = StampHistoryRecord(
                id = stampDocId,
                customerId = customer.uid,
                customerName = customer.name,
                orderId = orderId.ifBlank { "COUNTER_VISIT" },
                stampNumberInCycle = nextStamps,
                addedByUid = staffUser.uid,
                addedByName = staffUser.name,
                note = if (reachedFive) "5th Stamp! Free Reward Unlocked" else "Stamp #$nextStamps of 5 added",
                createdAt = now
            )

            tx.set(cardRef, updatedCard)
            tx.set(stampRef, historyRecord)
            tx.set(
                userRef,
                mapOf(
                    "loyaltyStamps" to finalCycleStamps,
                    "totalVisits" to (customer.totalVisits + 1),
                    "lastVisitAt" to now,
                    "updatedAt" to now
                ),
                SetOptions.merge()
            )

            if (orderId.isNotBlank()) {
                val orderRef = db.collection(COL_ORDERS).document(orderId)
                tx.update(orderRef, "stampAwarded", true)
            }

            if (reachedFive) {
                val rewardId = "RWD_${UUID.randomUUID().toString().take(8).uppercase()}"
                val reward = CustomerReward(
                    id = rewardId,
                    customerId = customer.uid,
                    customerName = customer.name,
                    customerPhone = customer.phone,
                    rewardTitle = settings.freeRewardTitle,
                    rewardCode = Formatters.generateRewardCode(),
                    isRedeemed = false,
                    unlockedAt = now
                )
                newlyUnlockedReward = reward
                tx.set(db.collection(COL_REWARDS).document(rewardId), reward)
            }
        }.await()

        Pair(updatedCard, newlyUnlockedReward)
    }

    /**
     * Redeems a customer reward code atomically and prevents duplicate redemption.
     */
    suspend fun redeemRewardByCode(
        rewardCode: String,
        staffUser: AppUser
    ): Result<CustomerReward> = runCatching {
        require(staffUser.role == UserRole.STAFF || staffUser.role == UserRole.OWNER) {
            "Unauthorized: Only Staff or Owner can verify and redeem rewards."
        }
        val cleanCode = rewardCode.trim().uppercase()
        val querySnap = db.collection(COL_REWARDS)
            .whereEqualTo("rewardCode", cleanCode)
            .limit(1)
            .get()
            .await()

        val doc = querySnap.documents.firstOrNull()
            ?: throw NoSuchElementException("Reward code $cleanCode not found.")

        var redeemedReward = CustomerReward()
        db.runTransaction { tx ->
            val freshSnap = tx.get(doc.reference)
            val current = freshSnap.toObject(CustomerReward::class.java)?.copy(id = freshSnap.id)
                ?: throw IllegalStateException("Invalid reward record.")
            if (current.isRedeemed) {
                throw IllegalStateException("Duplicate Redemption Blocked: Code $cleanCode was already redeemed.")
            }
            val now = System.currentTimeMillis()
            redeemedReward = current.copy(
                isRedeemed = true,
                redeemedAt = now,
                redeemedByStaffUid = staffUser.uid
            )
            tx.set(doc.reference, redeemedReward)
        }.await()

        redeemedReward
    }

    // =========================================================================
    // 5. Owner Product & Menu Management + Firebase Storage Upload
    // =========================================================================

    suspend fun uploadProductImageToStorage(imageUri: Uri, productId: String): Result<String> = runCatching {
        val storageRef = storage.reference.child("products/$productId/${UUID.randomUUID()}.jpg")
        storageRef.putFile(imageUri).await()
        storageRef.downloadUrl.await().toString()
    }

    suspend fun saveOrUpdateProduct(
        product: BakeryProduct,
        actorRole: UserRole
    ): Result<BakeryProduct> = runCatching {
        require(actorRole == UserRole.OWNER) {
            "Unauthorized: Only Owner/Admin can add or edit bakery products and prices."
        }
        require(product.name.trim().isNotEmpty()) { "Product name cannot be empty." }
        require(product.priceInr > 0.0) { "Product price (₹) must be greater than zero." }
        require(product.discountPercent in 0..90) { "Discount percentage must be between 0% and 90%." }

        val id = product.id.ifBlank { "prod_${UUID.randomUUID().toString().take(8)}" }
        val updated = product.copy(id = id, updatedAt = System.currentTimeMillis())
        db.collection(COL_PRODUCTS).document(id).set(updated).await()
        updated
    }

    suspend fun deleteProduct(productId: String, actorRole: UserRole): Result<Unit> = runCatching {
        require(actorRole == UserRole.OWNER) { "Unauthorized: Only Owner/Admin can delete products." }
        db.collection(COL_PRODUCTS).document(productId).delete().await()
    }

    // =========================================================================
    // 6. Owner QR Table Management & Come-Back Offers
    // =========================================================================

    suspend fun createOrUpdateTable(
        tableNumber: Int,
        label: String,
        seats: Int,
        actorRole: UserRole
    ): Result<BakeryTable> = runCatching {
        require(actorRole == UserRole.OWNER) { "Only Owner can manage table QR codes." }
        require(tableNumber in 1..200) { "Table number must be between 1 and 200." }
        val tableId = "TBL-${tableNumber.toString().padStart(2, '0')}"
        val qrPayload = "kusumbakery://table?tableId=$tableId&tableNumber=$tableNumber"
        val table = BakeryTable(
            id = tableId,
            tableNumber = tableNumber,
            label = label.ifBlank { "Table #$tableNumber" },
            seats = seats.coerceIn(1, 20),
            qrPayload = qrPayload,
            isActive = true,
            createdAt = System.currentTimeMillis()
        )
        db.collection(COL_TABLES).document(tableId).set(table).await()
        table
    }

    suspend fun createPromotionalOffer(
        offer: PromotionalOffer,
        actorRole: UserRole
    ): Result<PromotionalOffer> = runCatching {
        require(actorRole == UserRole.OWNER) { "Only Owner can create promotional Come-Back offers." }
        val id = offer.id.ifBlank { "offer_${UUID.randomUUID().toString().take(8)}" }
        val saved = offer.copy(
            id = id,
            promoCode = offer.promoCode.trim().uppercase(),
            createdAt = System.currentTimeMillis()
        )
        db.collection(COL_OFFERS).document(id).set(saved).await()
        saved
    }

    suspend fun recordComeBackOfferSent(
        customer: AppUser,
        offer: PromotionalOffer,
        actorRole: UserRole
    ): Result<OfferDeliveryRecord> = runCatching {
        require(actorRole == UserRole.OWNER) { "Only Owner can dispatch Come-Back offers." }
        require(customer.marketingConsent) {
            "Blocked: Customer ${customer.name} has not opted in to marketing messages."
        }
        val daysAbsent = Formatters.daysSinceIst(customer.lastVisitAt)
        val recordId = "OFFER_SEND_${customer.uid}_${offer.id}"
        val record = OfferDeliveryRecord(
            id = recordId,
            offerId = offer.id,
            offerTitle = offer.title,
            promoCode = offer.promoCode,
            customerId = customer.uid,
            customerName = customer.name,
            customerPhone = customer.phone,
            daysInactiveAtSend = daysAbsent,
            marketingConsentVerified = true,
            channel = "WHATSAPP_INDIVIDUAL",
            deliveryStatus = "SENT",
            customerReturned = false,
            sentAt = System.currentTimeMillis()
        )
        db.collection(COL_OFFER_HISTORY).document(recordId).set(record).await()
        record
    }

    suspend fun saveAppSettings(
        settings: BakeryAppSettings,
        actorRole: UserRole
    ): Result<BakeryAppSettings> = runCatching {
        require(actorRole == UserRole.OWNER) {
            "Security Violation: Only Owner/Admin can modify business settings."
        }
        val updated = settings.copy(updatedAt = System.currentTimeMillis())
        db.collection(COL_APP_SETTINGS).document("global_config").set(updated).await()
        updated
    }

    suspend fun seedDemoDataToFirestoreIfEmpty(): Result<Unit> = runCatching {
        val existingProducts = db.collection(COL_PRODUCTS).limit(1).get().await()
        if (!existingProducts.isEmpty) return@runCatching

        db.runBatch { batch ->
            DemoSeedData.defaultCategories().forEach { cat ->
                batch.set(db.collection(COL_CATEGORIES).document(cat.id), cat)
            }
            DemoSeedData.defaultProducts().forEach { prod ->
                batch.set(db.collection(COL_PRODUCTS).document(prod.id), prod)
            }
            DemoSeedData.defaultTables().forEach { tbl ->
                batch.set(db.collection(COL_TABLES).document(tbl.id), tbl)
            }
            DemoSeedData.defaultOffers().forEach { off ->
                batch.set(db.collection(COL_OFFERS).document(off.id), off)
            }
            DemoSeedData.defaultDemoCustomers().forEach { cust ->
                batch.set(db.collection(COL_USERS).document(cust.uid), cust)
                batch.set(
                    db.collection(COL_LOYALTY_CARDS).document(cust.uid),
                    LoyaltyCard(
                        customerId = cust.uid,
                        customerName = cust.name,
                        customerPhone = cust.phone,
                        currentStamps = cust.loyaltyStamps,
                        totalStampsEarned = cust.loyaltyStamps
                    )
                )
            }
            batch.set(db.collection(COL_APP_SETTINGS).document("global_config"), BakeryAppSettings())
        }.await()
    }
}
