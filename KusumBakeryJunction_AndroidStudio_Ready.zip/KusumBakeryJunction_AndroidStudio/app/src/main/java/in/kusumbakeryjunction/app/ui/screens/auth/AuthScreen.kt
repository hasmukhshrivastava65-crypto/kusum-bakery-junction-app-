package `in`.kusumbakeryjunction.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BakeryDining
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import `in`.kusumbakeryjunction.app.data.model.UserRole
import `in`.kusumbakeryjunction.app.ui.theme.*
import `in`.kusumbakeryjunction.app.viewmodel.KusumViewModel

@Composable
fun AuthScreen(viewModel: KusumViewModel) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var isOtpMode by remember { mutableStateOf(false) }
    var marketingConsent by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BakeryCreamBg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Temporary Brand Logo Placeholder
        Box(
            modifier = Modifier
                .size(84.dp)
                .clip(CircleShape)
                .background(BakeryChocolateDark),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.BakeryDining,
                contentDescription = "Kusum Bakery Junction Logo Placeholder",
                tint = BakeryGoldAccent,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Kusum Bakery Junction",
            style = MaterialTheme.typography.headlineLarge
        )
        Text(
            text = "Artisan Cakes, Pastries & Cafe • Bhopal, India",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Customer Registration / Phone Auth Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Customer Sign-In & Registration",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Sign in with your Indian mobile number (+91) to order from your table QR and earn loyalty stamps.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    placeholder = { Text("e.g., Aarav Sharma") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Mobile Number (+91)") },
                    placeholder = { Text("9826011223") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (isOtpMode) {
                    OutlinedTextField(
                        value = otpCode,
                        onValueChange = { otpCode = it },
                        label = { Text("6-Digit SMS OTP") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password (min 6 chars)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = marketingConsent,
                        onCheckedChange = { marketingConsent = it }
                    )
                    Text(
                        text = "I agree to receive exclusive Come-Back Offers & rewards on WhatsApp.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        viewModel.registerOrLoginCustomer(
                            name = name,
                            phone = phone,
                            password = if (isOtpMode) otpCode.ifBlank { "123456" } else password,
                            marketingConsent = marketingConsent
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                ) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isOtpMode) "Verify Phone OTP & Continue" else "Sign In / Register Customer")
                }

                TextButton(
                    onClick = { isOtpMode = !isOtpMode },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(
                        if (isOtpMode) "Switch to Password Login" else "Use Phone OTP Verification Instead"
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Role-Based Access Control (RBAC) Instant Switcher for Testing Customer, Staff & Owner
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = BakeryLatteCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Role-Based Access Portals (Verify All 3 Roles)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Test Customer, Staff, and Owner/Admin permissions enforced by Firebase Auth & Firestore Security Rules:",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.loginAsQuickRole(UserRole.CUSTOMER) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                ) {
                    Icon(Icons.Default.Person, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Enter as Customer (Aarav • 4/5 Stamps)")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { viewModel.loginAsQuickRole(UserRole.STAFF) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BakeryCaramelSecondary)
                ) {
                    Icon(Icons.Default.Badge, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Enter as Staff (Orders & 1-Tap Stamps)")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { viewModel.loginAsQuickRole(UserRole.OWNER) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolateDark)
                ) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Enter as Owner / Admin (Full Dashboard)")
                }
            }
        }
    }
}
