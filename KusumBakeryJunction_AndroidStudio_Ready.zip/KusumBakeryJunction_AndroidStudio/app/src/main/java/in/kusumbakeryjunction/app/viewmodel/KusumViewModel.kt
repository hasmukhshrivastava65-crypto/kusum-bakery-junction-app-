package `in`.kusumbakeryjunction.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.kusumbakeryjunction.app.data.model.*
import `in`.kusumbakeryjunction.app.data.repository.FirebaseBakeryRepository
import `in`.kusumbakeryjunction.app.util.BusinessLogicEngine
import `in`.kusumbakeryjunction.app.util.Formatters
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.TimeUnit

data class KusumUiState(
    val isLoading: Boolean = false,
    val isOfflineBannerVisible: Boolean = false,
    val statusBannerMessage: String? = null,
    val errorMessage: String? = null,
    val currentUser: AppUser? = null,
    val categories: List<BakeryCategory> = DemoSeedData.defaultCategories(),
    val products: List<BakeryProduct> = DemoSeedData.defaultProducts(),
    val selectedCategoryId: String = "ALL",
    val tables: List<BakeryTable> = DemoSeedData.defaultTables(),
    val scannedTable: BakeryTable? = DemoSeedData.defaultTables().firstOrNull(),
    val cart: List<CartItem> = emptyList(),
    val orders: List<BakeryOrder> = DemoSeedData.defaultDemoOrders(),
    val customers: List<AppUser> = DemoSeedData.defaultDemoCustomers(),
    val loyaltyCards: Map<String, LoyaltyCard> = emptyMap(),
    val stampHistory: List<StampHistoryRecord> = emptyList(),
    val rewards: List<CustomerReward> = emptyList(),
    val offers: List<PromotionalOffer> = DemoSeedData.defaultOffers(),
    val offerHistory: List<OfferDeliveryRecord> = emptyList(),
    val appSettings: BakeryAppSettings = BakeryAppSettings(),
    val selectedDateFilter: DateFilterRange = DateFilterRange.TODAY,
    val customStartDateMillis: Long = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(14),
    val customEndDateMillis: Long = System.currentTimeMillis(),
    val staffSearchPhoneQuery: String = ""
)

class KusumViewModel(
    private val repository: FirebaseBakeryRepository = FirebaseBakeryRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(KusumUiState())
    val uiState: StateFlow<KusumUiState> = _uiState.asStateFlow()

    init {
        initializeSeedStateAndListeners()
    }

    private fun initializeSeedStateAndListeners() {
        val now = System.currentTimeMillis()
        val demoCustomers = DemoSeedData.defaultDemoCustomers(now)
        val initialCards = demoCustomers.associate { cust ->
            cust.uid to LoyaltyCard(
                customerId = cust.uid,
                customerName = cust.name,
                customerPhone = cust.phone,
                currentStamps = cust.loyaltyStamps,
                totalStampsEarned = cust.loyaltyStamps + 5,
                totalRewardsUnlocked = 1,
                lastStampOrderId = "KBJ-DEMO-101"
            )
        }
        val initialRewards = listOf(
            CustomerReward(
                id = "RWD_DEMO_01",
                customerId = "cust_active_aarav",
                customerName = "Aarav Sharma",
                customerPhone = "+919826011223",
                rewardTitle = "Free Signature Pastry or Handcrafted Coffee (Up to ₹160)",
                rewardCode = "KBJ-RWD-AARAV5",
                isRedeemed = false,
                unlockedAt = now - TimeUnit.DAYS.toMillis(2)
            )
        )
        val initialHistory = listOf(
            StampHistoryRecord(
                id = "STAMP_DEMO_1",
                customerId = "cust_active_aarav",
                customerName = "Aarav Sharma",
                orderId = "KBJ-DEMO-101",
                stampNumberInCycle = 4,
                addedByUid = "staff_rahul",
                addedByName = "Rahul (Counter Staff)",
                note = "Stamp #4/5 added for Table #1 order",
                createdAt = now - TimeUnit.MINUTES.toMillis(25)
            )
        )
        val initialOfferHistory = listOf(
            OfferDeliveryRecord(
                id = "OFFER_HIST_DEMO_1",
                offerId = "offer_comeback_20",
                offerTitle = "We Miss You! 20% Off + Free Cappuccino",
                promoCode = "WELCOME20",
                customerId = "cust_inactive_priya",
                customerName = "Priya Nair",
                customerPhone = "+919826044556",
                daysInactiveAtSend = 26,
                marketingConsentVerified = true,
                channel = "WHATSAPP_INDIVIDUAL",
                deliveryStatus = "REDEEMED",
                customerReturned = true,
                sentAt = now - TimeUnit.DAYS.toMillis(3),
                redeemedAt = now - TimeUnit.DAYS.toMillis(1)
            )
        )

        _uiState.update {
            it.copy(
                loyaltyCards = initialCards,
                rewards = initialRewards,
                stampHistory = initialHistory,
                offerHistory = initialOfferHistory
            )
        }

        // Attach real-time Firestore listeners (gracefully falls back to offline cache if unconfigured)
        viewModelScope.launch {
            repository.seedDemoDataToFirestoreIfEmpty()
        }
    }

    fun clearBanners() {
        _uiState.update { it.copy(statusBannerMessage = null, errorMessage = null) }
    }

    // =========================================================================
    // Role-Based Authentication Actions
    // =========================================================================

    fun loginAsQuickRole(role: UserRole) {
        val now = System.currentTimeMillis()
        val user = when (role) {
            UserRole.CUSTOMER -> _uiState.value.customers.firstOrNull() ?: AppUser(
                uid = "cust_active_aarav",
                name = "Aarav Sharma",
                phone = "+919826011223",
                email = "aarav.sharma@example.com",
                role = UserRole.CUSTOMER,
                totalVisits = 4,
                lastVisitAt = now,
                loyaltyStamps = 4,
                marketingConsent = true
            )
            UserRole.STAFF -> AppUser(
                uid = "staff_rahul",
                name = "Rahul Sen (Barista & Counter Staff)",
                phone = "+919826055111",
                email = "staff@kusumbakery.in",
                role = UserRole.STAFF,
                isActive = true
            )
            UserRole.OWNER -> AppUser(
                uid = "owner_kusum_admin",
                name = "Kusum Bakery Owner / Admin",
                phone = "+919826000001",
                email = "owner@kusumbakery.in",
                role = UserRole.OWNER,
                isActive = true
            )
        }
        _uiState.update {
            it.copy(
                currentUser = user,
                statusBannerMessage = "Signed in as ${user.name} (${user.role.name})",
                errorMessage = null
            )
        }
    }

    fun registerOrLoginCustomer(
        name: String,
        phone: String,
        password: String,
        marketingConsent: Boolean
    ) {
        if (name.trim().length < 2) {
            _uiState.update { it.copy(errorMessage = "Please enter your full name (at least 2 characters).") }
            return
        }
        if (!Formatters.isValidIndianPhone(phone)) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid 10-digit Indian mobile number starting with 6-9.") }
            return
        }
        if (password.length < 6) {
            _uiState.update { it.copy(errorMessage = "Password must be at least 6 characters.") }
            return
        }

        val normalizedPhone = Formatters.normalizeIndianPhone(phone)
        val existing = _uiState.value.customers.find { it.phone == normalizedPhone }
        val user = existing?.copy(name = name.trim(), marketingConsent = marketingConsent)
            ?: AppUser(
                uid = "cust_${UUID.randomUUID().toString().take(8)}",
                name = name.trim(),
                phone = normalizedPhone,
                role = UserRole.CUSTOMER,
                totalVisits = 1,
                lastVisitAt = System.currentTimeMillis(),
                loyaltyStamps = 0,
                marketingConsent = marketingConsent
            )

        val updatedCustomers = (_uiState.value.customers.filterNot { it.uid == user.uid } + user)
        val updatedCards = _uiState.value.loyaltyCards.toMutableMap().apply {
            putIfAbsent(
                user.uid,
                LoyaltyCard(
                    customerId = user.uid,
                    customerName = user.name,
                    customerPhone = user.phone,
                    currentStamps = user.loyaltyStamps
                )
            )
        }

        _uiState.update {
            it.copy(
                currentUser = user,
                customers = updatedCustomers,
                loyaltyCards = updatedCards,
                statusBannerMessage = "Welcome to Kusum Bakery Junction, ${user.name}!",
                errorMessage = null
            )
        }

        viewModelScope.launch {
            repository.registerCustomerWithEmailOrPhone(name, phone, "", password, marketingConsent)
        }
    }

    fun logout() {
        repository.signOut()
        _uiState.update {
            it.copy(
                currentUser = null,
                cart = emptyList(),
                statusBannerMessage = "Signed out safely.",
                errorMessage = null
            )
        }
    }

    fun updateCustomerMarketingConsent(consent: Boolean) {
        val current = _uiState.value.currentUser ?: return
        val updatedUser = current.copy(marketingConsent = consent, updatedAt = System.currentTimeMillis())
        _uiState.update { state ->
            state.copy(
                currentUser = updatedUser,
                customers = state.customers.map { if (it.uid == updatedUser.uid) updatedUser else it },
                statusBannerMessage = if (consent) {
                    "Marketing offers enabled (WhatsApp Come-Back deals active)."
                } else {
                    "Marketing offers disabled. You will not receive promotional WhatsApp messages."
                }
            )
        }
    }

    // =========================================================================
    // Customer Section A: QR Table Ordering & Cart
    // =========================================================================

    fun selectCategory(categoryId: String) {
        _uiState.update { it.copy(selectedCategoryId = categoryId) }
    }

    fun onQrPayloadScanned(rawPayload: String) {
        val parsedId = Formatters.let {
            `in`.kusumbakeryjunction.app.util.QrCodeHelper.parseTableIdFromQrPayload(rawPayload)
        }
        if (parsedId == null) {
            _uiState.update { it.copy(errorMessage = "Invalid QR code scanned.") }
            return
        }
        val validTable = BusinessLogicEngine.validateTableForOrder(parsedId, _uiState.value.tables)
        if (validTable == null) {
            _uiState.update {
                it.copy(errorMessage = "Unrecognized or inactive Table ID ($parsedId). Please scan an official Kusum Bakery Junction table QR.")
            }
        } else {
            _uiState.update {
                it.copy(
                    scannedTable = validTable,
                    statusBannerMessage = "Connected to Table #${validTable.tableNumber} (${validTable.id})",
                    errorMessage = null
                )
            }
        }
    }

    fun addToCart(product: BakeryProduct) {
        if (!product.isAvailable) {
            _uiState.update { it.copy(errorMessage = "${product.name} is currently sold out.") }
            return
        }
        _uiState.update { state ->
            val existing = state.cart.find { it.product.id == product.id }
            val nextCart = if (existing != null) {
                state.cart.map {
                    if (it.product.id == product.id) it.copy(quantity = it.quantity + 1) else it
                }
            } else {
                state.cart + CartItem(product, 1)
            }
            state.copy(cart = nextCart, errorMessage = null)
        }
    }

    fun updateCartQuantity(productId: String, delta: Int) {
        _uiState.update { state ->
            val nextCart = state.cart.mapNotNull { item ->
                if (item.product.id == productId) {
                    val nextQty = item.quantity + delta
                    if (nextQty > 0) item.copy(quantity = nextQty) else null
                } else item
            }
            state.copy(cart = nextCart)
        }
    }

    fun placeTableOrder(customerNameInput: String, customerPhoneInput: String) {
        val state = _uiState.value
        val currentUser = state.currentUser ?: return
        val table = state.scannedTable
        if (table == null || BusinessLogicEngine.validateTableForOrder(table.id, state.tables) == null) {
            _uiState.update { it.copy(errorMessage = "Please scan or select a valid Table QR code before placing an order.") }
            return
        }
        if (state.cart.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Your cart is empty. Add bakery products first.") }
            return
        }
        val finalName = customerNameInput.trim().ifBlank { currentUser.name }
        val finalPhone = customerPhoneInput.trim().ifBlank { currentUser.phone }
        if (finalName.length < 2 || !Formatters.isValidIndianPhone(finalPhone)) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid customer name and 10-digit Indian phone number.") }
            return
        }

        val (subtotal, discount, total) = BusinessLogicEngine.calculateCartTotals(state.cart)
        val orderId = Formatters.generateOrderId()
        val now = System.currentTimeMillis()
        val normalizedPhone = Formatters.normalizeIndianPhone(finalPhone)

        // Prevent accidental duplicate rapid submission within 10 seconds
        val duplicateRecent = state.orders.any {
            it.customerId == currentUser.uid &&
                it.tableId == table.id &&
                it.totalAmount == total &&
                (now - it.createdAt) < 10_000L
        }
        if (duplicateRecent) {
            _uiState.update { it.copy(errorMessage = "Duplicate order prevented: Your identical order was just submitted.") }
            return
        }

        val items = state.cart.mapIndexed { idx, c ->
            OrderItemRecord(
                id = "${orderId}_${idx + 1}",
                orderId = orderId,
                customerId = currentUser.uid,
                productId = c.product.id,
                productName = c.product.name,
                quantity = c.quantity,
                unitPriceInr = c.product.effectivePriceInr,
                totalPriceInr = c.lineTotalInr,
                createdAt = now
            )
        }

        val newOrder = BakeryOrder(
            id = orderId,
            customerId = currentUser.uid,
            customerName = finalName,
            customerPhone = normalizedPhone,
            tableId = table.id,
            tableNumber = table.tableNumber,
            itemsSummary = items,
            subtotalInr = subtotal,
            discountInr = discount,
            totalAmount = total,
            status = OrderStatus.PENDING,
            stampAwarded = false,
            isDemoData = false,
            createdAt = now,
            updatedAt = now
        )

        _uiState.update {
            it.copy(
                orders = listOf(newOrder) + it.orders,
                cart = emptyList(),
                statusBannerMessage = "Order $orderId placed for Table #${table.tableNumber}! Status: Pending",
                errorMessage = null
            )
        }

        viewModelScope.launch {
            repository.validateAndPlaceTableOrder(
                customerId = currentUser.uid,
                customerName = finalName,
                customerPhone = normalizedPhone,
                tableId = table.id,
                cartItems = state.cart,
                availableTables = state.tables
            )
        }
    }

    // =========================================================================
    // Staff & Owner Order Status & Loyalty Operations
    // =========================================================================

    fun advanceOrderStatus(order: BakeryOrder, nextStatus: OrderStatus) {
        val actor = _uiState.value.currentUser ?: return
        if (actor.role != UserRole.STAFF && actor.role != UserRole.OWNER) {
            _uiState.update { it.copy(errorMessage = "Access Denied: Only Staff or Owner can update orders.") }
            return
        }
        val now = System.currentTimeMillis()
        _uiState.update { state ->
            state.copy(
                orders = state.orders.map {
                    if (it.id == order.id) it.copy(status = nextStatus, updatedAt = now) else it
                },
                statusBannerMessage = "Order ${order.id} marked as ${nextStatus.displayName}."
            )
        }
        viewModelScope.launch {
            repository.updateOrderStatus(order.id, nextStatus, actor.role)
        }
    }

    fun updateStaffSearchPhone(query: String) {
        _uiState.update { it.copy(staffSearchPhoneQuery = query) }
    }

    fun addOneTapLoyaltyStamp(customer: AppUser, orderId: String = "") {
        val state = _uiState.value
        val actor = state.currentUser ?: return
        val existingCard = state.loyaltyCards[customer.uid] ?: LoyaltyCard(
            customerId = customer.uid,
            customerName = customer.name,
            customerPhone = customer.phone,
            currentStamps = customer.loyaltyStamps
        )

        val result = BusinessLogicEngine.applyOneTapStamp(
            card = existingCard,
            orderId = orderId,
            existingStampHistory = state.stampHistory,
            staffUser = actor,
            rewardTitle = state.appSettings.freeRewardTitle
        )

        result.onSuccess { (updatedCard, historyRecord, unlockedReward) ->
            val updatedCustomer = customer.copy(
                loyaltyStamps = updatedCard.currentStamps,
                totalVisits = customer.totalVisits + 1,
                lastVisitAt = System.currentTimeMillis()
            )
            _uiState.update { s ->
                s.copy(
                    loyaltyCards = s.loyaltyCards + (customer.uid to updatedCard),
                    stampHistory = listOf(historyRecord) + s.stampHistory,
                    rewards = if (unlockedReward != null) listOf(unlockedReward) + s.rewards else s.rewards,
                    customers = s.customers.map { if (it.uid == customer.uid) updatedCustomer else it },
                    currentUser = if (s.currentUser?.uid == customer.uid) updatedCustomer else s.currentUser,
                    orders = if (orderId.isNotBlank()) {
                        s.orders.map { if (it.id == orderId) it.copy(stampAwarded = true) else it }
                    } else s.orders,
                    statusBannerMessage = if (unlockedReward != null) {
                        "🎉 5th Stamp Added for ${customer.name}! Unlocked Reward Code: ${unlockedReward.rewardCode}"
                    } else {
                        "Added Stamp #${historyRecord.stampNumberInCycle}/5 for ${customer.name}."
                    },
                    errorMessage = null
                )
            }
            viewModelScope.launch {
                repository.addLoyaltyStampAtomic(customer, orderId, actor, state.appSettings)
            }
        }.onFailure { err ->
            _uiState.update { it.copy(errorMessage = err.message) }
        }
    }

    fun redeemCustomerRewardCode(rewardCode: String) {
        val state = _uiState.value
        val actor = state.currentUser ?: return
        val effectiveStaff = if (actor.role == UserRole.CUSTOMER) {
            // Allow customer to trigger verification at the counter or Staff to redeem directly
            AppUser(uid = actor.uid, name = actor.name, role = UserRole.STAFF)
        } else actor

        val res = BusinessLogicEngine.redeemReward(
            rewardCode = rewardCode,
            rewards = state.rewards,
            staffUser = effectiveStaff
        )

        res.onSuccess { redeemed ->
            _uiState.update { s ->
                s.copy(
                    rewards = s.rewards.map { if (it.id == redeemed.id) redeemed else it },
                    statusBannerMessage = "Reward ${redeemed.rewardCode} redeemed for ${redeemed.customerName}!",
                    errorMessage = null
                )
            }
            viewModelScope.launch {
                repository.redeemRewardByCode(rewardCode, effectiveStaff)
            }
        }.onFailure { err ->
            _uiState.update { it.copy(errorMessage = err.message) }
        }
    }

    // =========================================================================
    // Owner Admin: Product CRUD, QR Table Management, Come-Back Offers, Settings
    // =========================================================================

    fun saveProduct(
        existingId: String?,
        name: String,
        description: String,
        categoryId: String,
        priceInrText: String,
        discountPercentText: String,
        imageUrl: String,
        isAvailable: Boolean,
        isDemoData: Boolean
    ) {
        val actor = _uiState.value.currentUser
        if (actor?.role != UserRole.OWNER) {
            _uiState.update { it.copy(errorMessage = "Access Denied: Only the Owner can manage menu products.") }
            return
        }
        val price = priceInrText.toDoubleOrNull()
        val discount = discountPercentText.toIntOrNull() ?: 0
        if (name.trim().isEmpty() || price == null || price <= 0.0) {
            _uiState.update { it.copy(errorMessage = "Enter a valid product name and price in ₹ (> 0).") }
            return
        }
        val cat = _uiState.value.categories.find { it.id == categoryId }
            ?: _uiState.value.categories.first()

        val prodId = existingId ?: "prod_${UUID.randomUUID().toString().take(6)}"
        val product = BakeryProduct(
            id = prodId,
            name = name.trim(),
            description = description.trim().ifBlank { "Freshly prepared at Kusum Bakery Junction." },
            categoryId = cat.id,
            categoryName = cat.name,
            priceInr = price,
            discountPercent = discount.coerceIn(0, 90),
            imageUrl = imageUrl.trim(),
            isAvailable = isAvailable,
            isDemoData = isDemoData
        )

        _uiState.update { state ->
            val exists = state.products.any { it.id == prodId }
            val nextList = if (exists) {
                state.products.map { if (it.id == prodId) product else it }
            } else {
                listOf(product) + state.products
            }
            state.copy(
                products = nextList,
                statusBannerMessage = "Saved product: ${product.name} (${Formatters.formatInr(product.effectivePriceInr)})",
                errorMessage = null
            )
        }

        viewModelScope.launch {
            repository.saveOrUpdateProduct(product, actor.role)
        }
    }

    fun toggleProductAvailability(product: BakeryProduct) {
        val actor = _uiState.value.currentUser ?: return
        if (actor.role != UserRole.OWNER && actor.role != UserRole.STAFF) return
        val updated = product.copy(isAvailable = !product.isAvailable, updatedAt = System.currentTimeMillis())
        _uiState.update { state ->
            state.copy(
                products = state.products.map { if (it.id == product.id) updated else it },
                statusBannerMessage = "${product.name} marked as ${if (updated.isAvailable) "Available" else "Sold Out"}."
            )
        }
    }

    fun deleteProduct(productId: String) {
        val actor = _uiState.value.currentUser
        if (actor?.role != UserRole.OWNER) {
            _uiState.update { it.copy(errorMessage = "Only the Owner can delete products.") }
            return
        }
        _uiState.update { state ->
            state.copy(
                products = state.products.filterNot { it.id == productId },
                statusBannerMessage = "Product removed from menu."
            )
        }
        viewModelScope.launch {
            repository.deleteProduct(productId, actor.role)
        }
    }

    fun addOrUpdateTableQr(tableNumber: Int, label: String, seats: Int) {
        val actor = _uiState.value.currentUser
        if (actor?.role != UserRole.OWNER) {
            _uiState.update { it.copy(errorMessage = "Only the Owner can generate Table QR codes.") }
            return
        }
        val id = "TBL-${tableNumber.toString().padStart(2, '0')}"
        val newTable = BakeryTable(
            id = id,
            tableNumber = tableNumber,
            label = label.ifBlank { "Table #$tableNumber" },
            seats = seats.coerceIn(1, 20),
            qrPayload = "kusumbakery://table?tableId=$id&tableNumber=$tableNumber",
            isActive = true
        )
        _uiState.update { state ->
            val filtered = state.tables.filterNot { it.id == id }
            state.copy(
                tables = (filtered + newTable).sortedBy { it.tableNumber },
                statusBannerMessage = "Generated QR code for Table #$tableNumber ($id).",
                errorMessage = null
            )
        }
        viewModelScope.launch {
            repository.createOrUpdateTable(tableNumber, label, seats, actor.role)
        }
    }

    fun createPromotionalOffer(
        title: String,
        description: String,
        promoCode: String,
        discountPercent: Int,
        maxDiscountInr: Double
    ) {
        val actor = _uiState.value.currentUser
        if (actor?.role != UserRole.OWNER) {
            _uiState.update { it.copy(errorMessage = "Only the Owner can create Come-Back offers.") }
            return
        }
        if (title.isBlank() || promoCode.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Offer title and promo code are required.") }
            return
        }
        val offer = PromotionalOffer(
            id = "offer_${UUID.randomUUID().toString().take(6)}",
            title = title.trim(),
            description = description.trim(),
            promoCode = promoCode.trim().uppercase(),
            discountPercent = discountPercent.coerceIn(5, 80),
            maxDiscountInr = maxDiscountInr.coerceAtLeast(25.0),
            isActive = true
        )
        _uiState.update { state ->
            state.copy(
                offers = listOf(offer) + state.offers,
                statusBannerMessage = "Created Come-Back Offer: ${offer.promoCode}",
                errorMessage = null
            )
        }
        viewModelScope.launch {
            repository.createPromotionalOffer(offer, actor.role)
        }
    }

    fun recordIndividualWhatsAppComeBackOffer(customer: AppUser, offer: PromotionalOffer) {
        val actor = _uiState.value.currentUser
        if (actor?.role != UserRole.OWNER) {
            _uiState.update { it.copy(errorMessage = "Only the Owner can dispatch Come-Back offers.") }
            return
        }
        if (!customer.marketingConsent) {
            _uiState.update {
                it.copy(errorMessage = "Blocked: ${customer.name} has opted out of marketing messages.")
            }
            return
        }
        val record = OfferDeliveryRecord(
            id = "OFFER_SEND_${UUID.randomUUID().toString().take(6)}",
            offerId = offer.id,
            offerTitle = offer.title,
            promoCode = offer.promoCode,
            customerId = customer.uid,
            customerName = customer.name,
            customerPhone = customer.phone,
            daysInactiveAtSend = Formatters.daysSinceIst(customer.lastVisitAt),
            marketingConsentVerified = true,
            channel = "WHATSAPP_INDIVIDUAL",
            deliveryStatus = "SENT",
            customerReturned = false
        )
        _uiState.update { state ->
            state.copy(
                offerHistory = listOf(record) + state.offerHistory,
                statusBannerMessage = "Recorded WhatsApp offer ${offer.promoCode} sent to ${customer.name}.",
                errorMessage = null
            )
        }
        viewModelScope.launch {
            repository.recordComeBackOfferSent(customer, offer, actor.role)
        }
    }

    fun markOfferCustomerReturned(historyId: String) {
        _uiState.update { state ->
            state.copy(
                offerHistory = state.offerHistory.map {
                    if (it.id == historyId) {
                        it.copy(
                            customerReturned = true,
                            deliveryStatus = "REDEEMED",
                            redeemedAt = System.currentTimeMillis()
                        )
                    } else it
                },
                statusBannerMessage = "Marked customer as returned & offer redeemed!"
            )
        }
    }

    fun setDateFilter(filter: DateFilterRange, customStart: Long = 0L, customEnd: Long = 0L) {
        _uiState.update {
            it.copy(
                selectedDateFilter = filter,
                customStartDateMillis = if (customStart > 0L) customStart else it.customStartDateMillis,
                customEndDateMillis = if (customEnd > 0L) customEnd else it.customEndDateMillis
            )
        }
    }

    fun updateAppSettings(
        freeRewardTitle: String,
        googleReviewUrl: String,
        comebackThresholdDays: Int,
        whatsAppApiEnabled: Boolean
    ) {
        val actor = _uiState.value.currentUser
        if (actor?.role != UserRole.OWNER) {
            _uiState.update { it.copy(errorMessage = "Security Restriction: Staff cannot modify Owner settings.") }
            return
        }
        val nextSettings = _uiState.value.appSettings.copy(
            freeRewardTitle = freeRewardTitle.trim().ifBlank { _uiState.value.appSettings.freeRewardTitle },
            googleReviewUrl = googleReviewUrl.trim().ifBlank { _uiState.value.appSettings.googleReviewUrl },
            comebackThresholdDays = comebackThresholdDays.coerceIn(7, 180),
            whatsAppBusinessApiEnabled = whatsAppApiEnabled,
            updatedAt = System.currentTimeMillis()
        )
        _uiState.update {
            it.copy(
                appSettings = nextSettings,
                statusBannerMessage = "Updated Kusum Bakery Junction business settings.",
                errorMessage = null
            )
        }
        viewModelScope.launch {
            repository.saveAppSettings(nextSettings, actor.role)
        }
    }
}
