package `in`.kusumbakeryjunction.app.ui.navigation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import `in`.kusumbakeryjunction.app.data.model.UserRole
import `in`.kusumbakeryjunction.app.ui.components.DemoDataDisclosureBanner
import `in`.kusumbakeryjunction.app.ui.components.FeedbackBanner
import `in`.kusumbakeryjunction.app.ui.components.KusumTopAppBar
import `in`.kusumbakeryjunction.app.ui.screens.auth.AuthScreen
import `in`.kusumbakeryjunction.app.ui.screens.customer.CustomerMainScreen
import `in`.kusumbakeryjunction.app.ui.screens.owner.OwnerAdminScreen
import `in`.kusumbakeryjunction.app.ui.screens.staff.StaffDashboardScreen
import `in`.kusumbakeryjunction.app.viewmodel.KusumViewModel

@Composable
fun KusumAppRoot(viewModel: KusumViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val currentUser = uiState.currentUser

    Column(modifier = Modifier.fillMaxSize()) {
        KusumTopAppBar(
            currentUser = currentUser,
            onLogout = { viewModel.logout() }
        )

        if (uiState.appSettings.showDemoDataBanner) {
            DemoDataDisclosureBanner()
        }

        FeedbackBanner(
            statusMessage = uiState.statusBannerMessage,
            errorMessage = uiState.errorMessage,
            onDismiss = { viewModel.clearBanners() }
        )

        when (currentUser?.role) {
            null -> AuthScreen(viewModel = viewModel)
            UserRole.CUSTOMER -> CustomerMainScreen(uiState = uiState, viewModel = viewModel)
            UserRole.STAFF -> StaffDashboardScreen(uiState = uiState, viewModel = viewModel)
            UserRole.OWNER -> OwnerAdminScreen(uiState = uiState, viewModel = viewModel)
        }
    }
}
