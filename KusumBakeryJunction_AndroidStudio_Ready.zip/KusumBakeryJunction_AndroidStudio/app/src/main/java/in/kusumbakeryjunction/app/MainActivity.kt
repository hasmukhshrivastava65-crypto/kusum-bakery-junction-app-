package `in`.kusumbakeryjunction.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import `in`.kusumbakeryjunction.app.ui.navigation.KusumAppRoot
import `in`.kusumbakeryjunction.app.ui.theme.KusumBakeryTheme
import `in`.kusumbakeryjunction.app.viewmodel.KusumViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: KusumViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIncomingTableQrIntent(intent)

        setContent {
            KusumBakeryTheme {
                KusumAppRoot(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingTableQrIntent(intent)
    }

    private fun handleIncomingTableQrIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "kusumbakery" && data.host == "table") {
            viewModel.onQrPayloadScanned(data.toString())
        }
    }
}
