package `in`.kusumbakeryjunction.app.data.model

import `in`.kusumbakeryjunction.app.util.Formatters
import java.util.concurrent.TimeUnit

enum class UserRole {
    CUSTOMER,
    STAFF,
    OWNER
}

enum class OrderStatus(val displayName: String) {
    PENDING("Pending"),
    ACCEPTED("Accepted"),
    PREPARING("Preparing"),
    READY("Ready"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled")
}

enum class DateFilterRange(val label: String) {
    TODAY("Today"),
    LAST_7_DAYS("Last 7 Days"),
    LAST_30_DAYS("Last 30 Days"),
    CUSTOM("Custom Range")
}

// Size / Portion Variant for Multi-Size Menu Items (Pizza S/M/L, Shakes Reg/Large, Patties Plain/Baked)
data class ProductVariant(
    val label: String = "Regular",
    val priceInr: Double = 0.0
)

// 1. users collection
data class AppUser(
    val uid: String = "",
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val role: UserRole = UserRole.CUSTOMER,
    val totalVisits: Int = 0,
    val lastVisitAt: Long = System.currentTimeMillis(),
    val loyaltyStamps: Int = 0,
    val marketingConsent: Boolean = true,
    val isActive: Boolean = true,
    val isDemoData: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// 2. categories collection
data class BakeryCategory(
    val id: String = "",
    val name: String = "",
    val iconEmoji: String = "🍕",
    val displayOrder: Int = 0,
    val isActive: Boolean = true
)

// 3. products collection
data class BakeryProduct(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val categoryId: String = "",
    val categoryName: String = "",
    val priceInr: Double = 0.0,
    val variants: List<ProductVariant> = emptyList(),
    val discountPercent: Int = 0,
    val imageUrl: String = "",
    val isAvailable: Boolean = true,
    val isDemoData: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
) {
    val effectivePriceInr: Double
        get() = if (discountPercent in 1..99) {
            Math.round(priceInr * (100 - discountPercent) / 100.0).toDouble()
        } else {
            priceInr
        }
}

// 4. tables collection
data class BakeryTable(
    val id: String = "",
    val tableNumber: Int = 1,
    val label: String = "",
    val seats: Int = 4,
    val qrPayload: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

// Cart Item (UI & Order Creation Helper)
data class CartItem(
    val product: BakeryProduct,
    val quantity: Int,
    val selectedVariantLabel: String = ""
) {
    val lineTotalInr: Double
        get() = product.effectivePriceInr * quantity
}

// 5. orders collection
data class BakeryOrder(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val tableId: String = "",
    val tableNumber: Int = 1,
    val itemsSummary: List<OrderItemRecord> = emptyList(),
    val subtotalInr: Double = 0.0,
    val discountInr: Double = 0.0,
    val totalAmount: Double = 0.0,
    val status: OrderStatus = OrderStatus.PENDING,
    val stampAwarded: Boolean = false,
    val isDemoData: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// 6. orderItems collection
data class OrderItemRecord(
    val id: String = "",
    val orderId: String = "",
    val customerId: String = "",
    val productId: String = "",
    val productName: String = "",
    val quantity: Int = 1,
    val unitPriceInr: Double = 0.0,
    val totalPriceInr: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

// 7. loyaltyCards collection
data class LoyaltyCard(
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val currentStamps: Int = 0, // 0..5 slots
    val totalStampsEarned: Int = 0,
    val totalRewardsUnlocked: Int = 0,
    val lastStampOrderId: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

// 8. stampHistory collection
data class StampHistoryRecord(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val orderId: String = "",
    val stampNumberInCycle: Int = 1,
    val addedByUid: String = "",
    val addedByName: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// 9. rewards collection
data class CustomerReward(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val rewardTitle: String = "Free Chocolate Truffle Pastry (₹45) or Cold Coffee (₹45)",
    val rewardCode: String = "",
    val isRedeemed: Boolean = false,
    val redeemedAt: Long = 0L,
    val redeemedByStaffUid: String = "",
    val unlockedAt: Long = System.currentTimeMillis()
)

// 10. offers collection
data class PromotionalOffer(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val promoCode: String = "",
    val discountPercent: Int = 15,
    val maxDiscountInr: Double = 150.0,
    val minOrderInr: Double = 250.0,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

// 11. offerHistory collection
data class OfferDeliveryRecord(
    val id: String = "",
    val offerId: String = "",
    val offerTitle: String = "",
    val promoCode: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val daysInactiveAtSend: Long = 21L,
    val marketingConsentVerified: Boolean = true,
    val channel: String = "WHATSAPP_INDIVIDUAL",
    val deliveryStatus: String = "SENT", // SENT, DELIVERED, REDEEMED
    val customerReturned: Boolean = false,
    val sentAt: Long = System.currentTimeMillis(),
    val redeemedAt: Long = 0L
)

// 12. appSettings collection
data class BakeryAppSettings(
    val id: String = "global_config",
    val businessName: String = "Kusum Bakery Junction",
    val branchCity: String = "Bhopal, Madhya Pradesh, India",
    val currencySymbol: String = "₹",
    val timezoneId: String = "Asia/Kolkata",
    val loyaltyStampsRequired: Int = 5,
    val freeRewardTitle: String = "Free Chocolate Truffle Pastry (₹45) or Cold Coffee (₹45)",
    val googleReviewUrl: String = "https://www.google.com/maps/search/?api=1&query=Kusum+Bakery+Junction+Bhopal",
    val comebackThresholdDays: Int = 21,
    val whatsAppBusinessApiEnabled: Boolean = false,
    val whatsAppBusinessPhoneId: String = "",
    val showDemoDataBanner: Boolean = false,
    val comingSoonAnnouncement: String = "VEG DUM BIRYANI, CHILLI PANEER, KOTHEY, FRIED RICE AND MANY MORE START SOON",
    val updatedAt: Long = System.currentTimeMillis()
)

// Analytics Summary for Owner Admin Dashboard
data class OwnerDashboardMetrics(
    val filterRange: DateFilterRange = DateFilterRange.TODAY,
    val filteredOrdersCount: Int = 0,
    val filteredSalesInr: Double = 0.0,
    val todayOrdersCount: Int = 0,
    val todaySalesInr: Double = 0.0,
    val monthlySalesInr: Double = 0.0,
    val pendingOrdersCount: Int = 0,
    val totalCustomersCount: Int = 0,
    val newCustomersCount: Int = 0,
    val repeatCustomerPercentage: Double = 0.0,
    val topSellingProducts: List<Pair<String, Int>> = emptyList(),
    val offersSentCount: Int = 0,
    val customersReturnedAfterOfferCount: Int = 0,
    val loyaltyRewardsRedeemedCount: Int = 0
)

/**
 * Official Kusum Bakery Junction Menu Catalog (All 15 Categories & 84 Exact Menu Items in ₹)
 */
object DemoSeedData {

    fun defaultCategories(): List<BakeryCategory> = listOf(
        BakeryCategory("cat_pizza", "Pizza", "🍕", 1),
        BakeryCategory("cat_vpc", "V.P.C.", "🥙", 2),
        BakeryCategory("cat_pasta", "Pasta", "🍝", 3),
        BakeryCategory("cat_burger", "Burger", "🍔", 4),
        BakeryCategory("cat_sandwiches", "Sandwiches", "🥪", 5),
        BakeryCategory("cat_pav_bhaji", "Pav Bhaji", "🍛", 6),
        BakeryCategory("cat_hotdog", "Hotdog", "🌭", 7),
        BakeryCategory("cat_garlic_bread", "Garlic Bread", "🥖", 8),
        BakeryCategory("cat_mocktail", "Mocktail", "🍹", 9),
        BakeryCategory("cat_shakes", "Shakes", "🥤", 10),
        BakeryCategory("cat_maggi", "Maggi", "🍜", 11),
        BakeryCategory("cat_dessert", "Dessert", "🍰", 12),
        BakeryCategory("cat_patties", "Patties", "🥐", 13),
        BakeryCategory("cat_coffee", "Coffee & Fries", "☕", 14),
        BakeryCategory("cat_momos", "Momos", "🥟", 15),
        BakeryCategory("cat_rice_bowl", "Rice Bowl", "🍚", 16)
    )

    private fun pizza3(id: String, name: String, s: Double, m: Double, l: Double, desc: String) = BakeryProduct(
        id = id,
        name = name,
        description = desc,
        categoryId = "cat_pizza",
        categoryName = "Pizza",
        priceInr = s,
        variants = listOf(
            ProductVariant("Small (₹${s.toInt()})", s),
            ProductVariant("Medium (₹${m.toInt()})", m),
            ProductVariant("Large (₹${l.toInt()})", l)
        ),
        isAvailable = true,
        isDemoData = false
    )

    private fun pizza2(id: String, name: String, r: Double, m: Double, desc: String) = BakeryProduct(
        id = id,
        name = name,
        description = desc,
        categoryId = "cat_pizza",
        categoryName = "Pizza",
        priceInr = r,
        variants = listOf(
            ProductVariant("Regular (₹${r.toInt()})", r),
            ProductVariant("Medium (₹${m.toInt()})", m)
        ),
        isAvailable = true,
        isDemoData = false
    )

    private fun item1(id: String, catId: String, catName: String, name: String, price: Double, desc: String) = BakeryProduct(
        id = id,
        name = name,
        description = desc,
        categoryId = catId,
        categoryName = catName,
        priceInr = price,
        variants = listOf(ProductVariant("Standard (₹${price.toInt()})", price)),
        isAvailable = true,
        isDemoData = false
    )

    private fun item2(id: String, catId: String, catName: String, name: String, l1: String, p1: Double, l2: String, p2: Double, desc: String) = BakeryProduct(
        id = id,
        name = name,
        description = desc,
        categoryId = catId,
        categoryName = catName,
        priceInr = p1,
        variants = listOf(
            ProductVariant("$l1 (₹${p1.toInt()})", p1),
            ProductVariant("$l2 (₹${p2.toInt()})", p2)
        ),
        isAvailable = true,
        isDemoData = false
    )

    fun defaultProducts(): List<BakeryProduct> = listOf(
        // 1. PIZZA (16 Items)
        pizza3("p_pizza_extra_cheese", "Extra Cheese (Pizza Add-on)", 35.0, 60.0, 85.0, "Extra mozzarella cheese topping (35/- | 60/- | 85/-)."),
        pizza2("p_onion_pizza", "Onion Pizza", 70.0, 190.0, "Freshly baked crust topped with crunchy onions & mozzarella (70/- | 190/-)."),
        pizza2("p_capsicum_pizza", "Capsicum Pizza", 80.0, 190.0, "Crisp green capsicum & molten cheese pizza (80/- | 190/-)."),
        pizza2("p_tomato_pizza", "Tomato Pizza", 80.0, 190.0, "Juicy ripe tomatoes & herb cheese blend (80/- | 190/-)."),
        pizza2("p_golden_corn_pizza", "Golden Corn Pizza", 90.0, 190.0, "Sweet golden corn kernels over rich pizza sauce & cheese (90/- | 190/-)."),
        pizza2("p_chilli_paneer_pizza", "Chilli Paneer Pizza", 100.0, 200.0, "Spiced chilli paneer cubes with capsicum & mozzarella (100/- | 200/-)."),
        pizza2("p_margherita_pizza", "Margherita Pizza", 120.0, 200.0, "Classic double mozzarella cheese & Italian herb sauce (120/- | 200/-)."),
        pizza3("p_paneer_corn_pizza", "Paneer Corn Pizza", 120.0, 220.0, 400.0, "Fresh paneer cubes & sweet golden corn (120/- | 220/- | 400/-)."),
        pizza3("p_onion_capsicum_pizza", "Onion Capsicum Pizza", 120.0, 220.0, 400.0, "Roasted onion & crunchy capsicum duo (120/- | 220/- | 400/-)."),
        pizza3("p_chatpata_onion_paneer_pizza", "Chatpata Onion Paneer Pizza", 120.0, 220.0, 400.0, "Tangy chatpata spiced paneer & onion slices (120/- | 220/- | 400/-)."),
        pizza3("p_corn_onion_pizza", "Corn Onion Pizza", 120.0, 220.0, 400.0, "Sweet golden corn & crunchy onion topping (120/- | 220/- | 400/-)."),
        pizza3("p_farm_house_pizza", "Farm House Pizza", 140.0, 270.0, 500.0, "Loaded garden fresh veggies, onion, capsicum, tomato & corn (140/- | 270/- | 500/-)."),
        pizza3("p_gardening_pizza", "Gardening Pizza", 160.0, 300.0, 560.0, "Chef's special garden supreme pizza loaded with veggies (160/- | 300/- | 560/-)."),
        pizza3("p_triple_spicy_paneer_pizza", "Triple Spicy Paneer Pizza", 160.0, 310.0, 560.0, "Fiery triple spiced paneer, jalapeños, capsicum & cheese (160/- | 310/- | 560/-)."),
        pizza3("p_town_down_pizza", "Town Down Pizza", 170.0, 320.0, 570.0, "Signature Kusum Bakery Junction loaded specialty pizza (170/- | 320/- | 570/-)."),
        pizza3("p_veggie_delight_pizza", "Veggie Delight Pizza", 170.0, 320.0, 570.0, "Exotic vegetables & extra creamy cheese delight (170/- | 320/- | 570/-)."),
        pizza3("p_momos_pizza", "Momos Pizza", 180.0, 340.0, 580.0, "Fusion pizza topped with juicy spiced veg momos & peri-peri cheese (180/- | 340/- | 580/-)."),

        // 2. V.P.C. (7 Items)
        item1("p_vpc_fresh_vegi", "cat_vpc", "V.P.C.", "V.P.C. (Fresh Vegi)", 60.0, "Crispy Fresh Vegi V.P.C. specialty (60/-)."),
        item1("p_vpv_cheesy", "cat_vpc", "V.P.C.", "V.P.V. (Cheesy Flavour)", 70.0, "Rich cheesy flavour V.P.V. delight (70/-)."),
        item1("p_vpc_tandoori", "cat_vpc", "V.P.C.", "V.P.C. (Tandoori Flavour)", 70.0, "Smoky tandoori mayo & spice infused V.P.C. (70/-)."),
        item1("p_vpc_makhani", "cat_vpc", "V.P.C.", "V.P.C. Makhani", 70.0, "Creamy makhani gravy style V.P.C. (70/-)."),
        item1("p_vpc_schezwan", "cat_vpc", "V.P.C.", "V.P.C. Schezwan", 70.0, "Fiery Schezwan sauce infused V.P.C. (70/-)."),
        item1("p_vpc_italian", "cat_vpc", "V.P.C.", "V.P.C. Italian", 70.0, "Herbed Italian seasoning & cheese V.P.C. (70/-)."),
        item1("p_vpc_paneer_saucy", "cat_vpc", "V.P.C.", "V.P.C. Paneer Saucy", 80.0, "Loaded paneer cubes & signature saucy dressing V.P.C. (80/-)."),

        // 3. PASTA (5 Items)
        item1("p_red_arrabiata_pasta", "cat_pasta", "Pasta", "Red Arrabiata Pasta", 90.0, "Penne tossed in tangy spiced Italian red tomato arrabiata sauce (90/-)."),
        item1("p_tandoori_gravy_pasta", "cat_pasta", "Pasta", "Tandoori Gravy Pasta", 120.0, "Fusion pasta cooked in smoky creamy tandoori gravy (120/-)."),
        item1("p_pink_sauce_pasta", "cat_pasta", "Pasta", "Pink Sauce Pasta", 100.0, "Creamy blend of classic white cheese & tangy red arrabiata sauce (100/-)."),
        item1("p_white_sauce_pasta", "cat_pasta", "Pasta", "White Sauce Pasta", 120.0, "Rich & velvety cheesy béchamel white sauce pasta with herbs (120/-)."),
        item1("p_makhani_sauce_pasta", "cat_pasta", "Pasta", "Makhani Sauce Pasta", 120.0, "Penne tossed in rich buttery Indian makhani sauce (120/-)."),

        // 4. BURGER (14 Items)
        item1("p_burger_extra_cheese", "cat_burger", "Burger", "Extra Cheese (Burger Add-on)", 30.0, "Extra cheese slice add-on for any burger (30/-)."),
        item1("p_mini_burger", "cat_burger", "Burger", "Mini Burger", 30.0, "Crisp veg patty in a soft toasted mini bun (30/-)."),
        item1("p_zinger_burger", "cat_burger", "Burger", "Zinger Burger", 60.0, "Extra crunchy zinger patty with signature burger mayo & lettuce (60/-)."),
        item1("p_makhani_burger_60", "cat_burger", "Burger", "Makhani Burger", 60.0, "Crispy patty glazed with rich makhani sauce in toasted sesame bun (60/-)."),
        item1("p_tandoori_burger", "cat_burger", "Burger", "Tandoori Burger", 80.0, "Smoky tandoori sauce, fresh onion rings & crispy veg patty (80/-)."),
        item1("p_cheesy_bunch_burger", "cat_burger", "Burger", "Cheesy Bunch Burger", 80.0, "Loaded with molten liquid cheese & herb veg patty (80/-)."),
        item1("p_makhani_cheese_burger", "cat_burger", "Burger", "Makhani Cheese Burger", 80.0, "Buttery makhani dressing paired with a melted cheese slice (80/-)."),
        item1("p_tandoori_cheese_burger", "cat_burger", "Burger", "Tandoori Cheese Burger", 80.0, "Smoky tandoori mayo & rich melted cheese slice burger (80/-)."),
        item1("p_crispy_burger", "cat_burger", "Burger", "Crispy Burger", 80.0, "Double-crunch golden vegetable patty burger (80/-)."),
        item1("p_makhani_burger_special", "cat_burger", "Burger", "Makhani Burger (Special Jumbo)", 90.0, "Deluxe jumbo makhani burger with extra veggies & dressing (90/-)."),
        item1("p_paneer_makhani_burger", "cat_burger", "Burger", "Paneer Makhani Burger", 90.0, "Spiced paneer fillet & crispy patty in creamy makhani sauce (90/-)."),
        item1("p_tandoori_paneer_burger", "cat_burger", "Burger", "Tandoori Paneer Burger", 90.0, "Grilled tandoori paneer slab with crunchy veggies & mint mayo (90/-)."),
        item1("p_volcano_burger", "cat_burger", "Burger", "Volcano Burger", 120.0, "Ultimate cheese-burst volcano burger overflowing with spiced molten cheese (120/-)."),

        // 5. SANDWICHES (7 Items)
        item1("p_sandwich_extra_cheese", "cat_sandwiches", "Sandwiches", "Extra Cheese (Sandwich Add-on)", 30.0, "Extra grated cheese add-on for sandwiches (30/-)."),
        item1("p_fresh_veggi_sandwich", "cat_sandwiches", "Sandwiches", "Fresh Veggi Sandwiches", 60.0, "Fresh garden cucumber, tomato, onion & green chutney sandwich (60/-)."),
        item1("p_cheese_sandwich", "cat_sandwiches", "Sandwiches", "Cheese Sandwiches", 80.0, "Golden grilled sandwich stuffed with generous melted cheese (80/-)."),
        item1("p_tandoori_sandwich", "cat_sandwiches", "Sandwiches", "Tandoori Sandwiches", 80.0, "Grilled veggie sandwich tossed in smoky tandoori dressing (80/-)."),
        item1("p_mexican_sandwich", "cat_sandwiches", "Sandwiches", "Maxican Sandwiches", 90.0, "Zesty Mexican salsa, sweet corn, capsicum & cheese grilled sandwich (90/-)."),
        item1("p_paneer_sandwich", "cat_sandwiches", "Sandwiches", "Paneer Sandwiches", 100.0, "Spiced cottage cheese cubes & veggies grilled to perfection (100/-)."),
        item1("p_paneer_corn_sandwich", "cat_sandwiches", "Sandwiches", "Paneer Corn Sandwiches", 120.0, "Loaded paneer, sweet golden corn & melted mozzarella grilled sandwich (120/-)."),

        // 6. PAV BHAJI (3 Items)
        item1("p_extra_pav", "cat_pav_bhaji", "Pav Bhaji", "Extra Pav", 20.0, "Butter-toasted soft bakery pav (20/-)."),
        item1("p_extra_bhaji", "cat_pav_bhaji", "Pav Bhaji", "Extra Bhaji", 45.0, "Extra portion of spiced Mumbai-style mashed vegetable bhaji (45/-)."),
        item1("p_pav_bhaji", "cat_pav_bhaji", "Pav Bhaji", "Pav Bhaji", 70.0, "Rich butter pav bhaji served with 2 toasted pavs, chopped onion & lemon (70/-)."),

        // 7. HOTDOG (4 Items)
        item1("p_desi_style_hotdog", "cat_hotdog", "Hotdog", "Desi Style Hotdog", 60.0, "Bakery hotdog roll stuffed with spiced desi masala filling & sauces (60/-)."),
        item1("p_cheesy_hotdog", "cat_hotdog", "Hotdog", "Cheesy Hotdog", 70.0, "Warm grilled hotdog loaded with creamy liquid & grated cheese (70/-)."),
        item1("p_mexican_spicy_hotdog", "cat_hotdog", "Hotdog", "Mexican Spicy Hot Dog", 75.0, "Zesty Mexican jalapeño & spicy herb dressing hotdog (75/-)."),
        item1("p_chilli_paneer_hotdog", "cat_hotdog", "Hotdog", "Chilli Paneer Hot Dog", 80.0, "Stuffed with Indo-Chinese chilli paneer cubes & melted cheese (80/-)."),

        // 8. GARLIC BREAD (5 Items)
        item1("p_garlic_bread_stick", "cat_garlic_bread", "Garlic Bread", "Garlic Bread Stick", 40.0, "Freshly baked crispy herb & garlic butter breadsticks (40/-)."),
        item1("p_garlic_bread_slice_4", "cat_garlic_bread", "Garlic Bread", "Garlic Bread Slice (4piece)", 40.0, "4 pieces of toasted artisan garlic butter bread slices (40/-)."),
        item1("p_cheesy_garlic_bread_sticks", "cat_garlic_bread", "Garlic Bread", "Cheesy Garlic Bread Sticks", 70.0, "Baked garlic breadsticks topped with bubbling mozzarella cheese (70/-)."),
        item1("p_cheesy_garlic_bread_slice_4", "cat_garlic_bread", "Garlic Bread", "Cheesy Garlic Br. Sl. (4piece)", 70.0, "4 pieces of garlic bread slices loaded with melted mozzarella (70/-)."),
        item1("p_chatpati_garlic_bread", "cat_garlic_bread", "Garlic Bread", "Chatpati Garlic Bread", 80.0, "Tangy & spicy chatpati masala cheesy garlic bread (80/-)."),

        // 9. MOCKTAIL (4 Items)
        item1("p_virgin_mojito", "cat_mocktail", "Mocktail", "Virgin Mojito", 45.0, "Refreshing muddled mint leaves, lime & sparkling fizz (45/-)."),
        item1("p_blueberry_smash_mojito", "cat_mocktail", "Mocktail", "Blueberry Smash Mojito", 45.0, "Chilled blueberry crush, fresh mint & citrus fizz (45/-)."),
        item1("p_red_crush_mojito", "cat_mocktail", "Mocktail", "Red Crush Mojito", 45.0, "Berry red crush cooler with lime & mint (45/-)."),
        item1("p_orange_smash_mojito", "cat_mocktail", "Mocktail", "Orange Smash Mojito", 45.0, "Tangy orange smash refresher with mint & ice (45/-)."),

        // 10. SHAKES (5 Items - Regular / Large)
        item2("p_strawberry_shakes", "cat_shakes", "Shakes", "Strawberry Shakes", "Regular", 45.0, "Large", 60.0, "Creamy strawberry milkshake (45/60)."),
        item2("p_pineapple_shakes", "cat_shakes", "Shakes", "Pineapple Shakes", "Regular", 45.0, "Large", 70.0, "Tropical pineapple thick shake (45/70)."),
        item2("p_mango_shakes", "cat_shakes", "Shakes", "Mango Shakes", "Regular", 45.0, "Large", 70.0, "Rich Alphonso mango milkshake (45/70)."),
        item2("p_chocolate_shakes", "cat_shakes", "Shakes", "Chocolate Shakes", "Regular", 55.0, "Large", 80.0, "Belgian dark cocoa chocolate shake (55/80)."),
        item2("p_oreo_shakes", "cat_shakes", "Shakes", "Oreo Shakes", "Regular", 65.0, "Large", 85.0, "Crunchy Oreo cookie blended thick shake (65/85)."),

        // 11. MAGGI (5 Items)
        item1("p_simple_maggi", "cat_maggi", "Maggi", "Simple Maggi", 45.0, "Classic hot & comforting masala Maggi noodles (45/-)."),
        item1("p_veg_maggi", "cat_maggi", "Maggi", "Veg. Maggi", 65.0, "Cooked with crunchy onion, capsicum, peas & carrots (65/-)."),
        item1("p_spicsy_crion_maggi", "cat_maggi", "Maggi", "Spicsy Crion Maggi", 75.0, "Fiery spicy onion & garlic tadka Maggi noodles (75/-)."),
        item1("p_cheese_corn_maggi", "cat_maggi", "Maggi", "Cheese Corn Maggi", 85.0, "Creamy melted cheese & sweet golden corn Maggi (85/-)."),
        item1("p_tandoori_cheese_maggi", "cat_maggi", "Maggi", "Tandoori Cheese Maggi", 95.0, "Signature smoky tandoori gravy & molten cheese Maggi (95/-)."),

        // 12. DESSERT (4 Items)
        item1("p_star_cake", "cat_dessert", "Dessert", "Star Cake", 35.0, "Soft freshly baked Kusum Bakery star cake (35/-)."),
        item1("p_choco_truffle_pastry", "cat_dessert", "Dessert", "Chocolate Truffle Pastry", 45.0, "Rich layered dark chocolate ganache truffle pastry (45/-)."),
        item1("p_chocolate_cake", "cat_dessert", "Dessert", "Chocolate Cake", 60.0, "Decadent chocolate sponge slice with fudge frosting (60/-)."),
        item1("p_brownie", "cat_dessert", "Dessert", "Brownie", 60.0, "Warm walnut & dark chocolate fudge brownie (60/-)."),

        // 13. PATTIES (7 Items - Standard / Special Cheese-Masala)
        item2("p_aloo_patties", "cat_patties", "Patties", "Aloo Patties", "Standard", 25.0, "Special", 30.0, "Golden flaky puff pastry stuffed with spiced potato (25/- 30/-)."),
        item2("p_palak_paneer_patties", "cat_patties", "Patties", "Palak Paneer Patties", "Standard", 35.0, "Special", 40.0, "Flaky puff filled with spinach & cottage cheese (35/- 40/-)."),
        item2("p_masala_paneer_patties", "cat_patties", "Patties", "Masala Paneer Patties", "Standard", 35.0, "Special", 40.0, "Spiced masala paneer stuffed bakery puff (35/- 40/-)."),
        item2("p_chilli_paneer_patties", "cat_patties", "Patties", "Chilli Paneer Patties", "Standard", 35.0, "Special", 40.0, "Zesty Indo-Chinese chilli paneer puff pastry (35/- 40/-)."),
        item2("p_aloo_paneer_patties", "cat_patties", "Patties", "Aloo Paneer Patties", "Standard", 35.0, "Special", 40.0, "Classic aloo & paneer masala blend puff (35/- 40/-)."),
        item2("p_cheese_corn_patties", "cat_patties", "Patties", "Cheese Corn Patties", "Standard", 40.0, "Special", 45.0, "Melted cheese & sweet golden corn flaky puff (40/- 45/-)."),
        item1("p_jungle_patties", "cat_patties", "Patties", "Jungle Patties", 60.0, "Kusum Bakery signature fully-loaded sauces, veggies & paneer Jungle Patties (60/-)."),

        // 14. COFFEE & FRIES (3 Items)
        item2("p_cold_coffee", "cat_coffee", "Coffee & Fries", "Cold Coffee", "Regular", 45.0, "Large", 70.0, "Frothy café-style chilled cold coffee (45/70/-)."),
        item2("p_cold_coffee_ice_cream", "cat_coffee", "Coffee & Fries", "Cold Coffee With Ice Cream", "Regular", 50.0, "Large", 85.0, "Rich cold coffee topped with a scoop of vanilla ice cream (50/85/-)."),
        item1("p_french_fries", "cat_coffee", "Coffee & Fries", "French Fries", 65.0, "Crispy golden salted & peri-peri French fries (65/-)."),

        // 15. MOMOS (7 Items)
        item1("p_veg_stream_momos", "cat_momos", "Momos", "Veg Stream Momos", 60.0, "Hot steamed vegetable dumplings served with fiery red chutney (60/-)."),
        item1("p_veg_momos_fried", "cat_momos", "Momos", "Veg Momos Fried", 80.0, "Crispy golden fried vegetable momos with spicy dip (80/-)."),
        item1("p_paneer_stream_momos", "cat_momos", "Momos", "Paneer Stream Momos", 90.0, "Juicy steamed momos stuffed with spiced paneer filling (90/-)."),
        item1("p_paneer_momos_fried", "cat_momos", "Momos", "Paneer Momos Fried", 100.0, "Crunchy fried paneer momos served with schezwan & mayo dip (100/-)."),
        item1("p_cheese_corn_stream_momos", "cat_momos", "Momos", "Cheese Corn Stream Momos", 100.0, "Steamed dumplings filled with molten cheese & sweet corn (100/-)."),
        item1("p_cheese_corn_momos_fried", "cat_momos", "Momos", "Cheese Corn Momos Fried", 110.0, "Crispy fried cheese & golden corn momos (110/-)."),
        item1("p_darjeeling_momos", "cat_momos", "Momos", "Darjeeling Momos", 150.0, "Authentic Himalayan Darjeeling style special platter momos (150/-)."),

        // 16. RICE BOWL (2 Active + Upcoming Menu Items)
        item1("p_chole_rice_bowl", "cat_rice_bowl", "Rice Bowl", "Chole Rice Bowl", 90.0, "Homestyle spiced Amritsari chole served over aromatic basmati rice (90/-)."),
        item1("p_rajma_rice_bowl", "cat_rice_bowl", "Rice Bowl", "Rajma Rice Bowl", 90.0, "Rich Punjabi rajma masala served over steamed basmati rice (90/-).")
    )

    fun defaultTables(): List<BakeryTable> = (1..8).map { num ->
        val id = "TBL-0$num"
        BakeryTable(
            id = id,
            tableNumber = num,
            label = "Table #$num (${if (num <= 4) "Indoor Cafe" else "Garden Patio"})",
            seats = if (num % 2 == 0) 4 else 2,
            qrPayload = "kusumbakery://table?tableId=$id&tableNumber=$num",
            isActive = true
        )
    }

    fun defaultOffers(): List<PromotionalOffer> = listOf(
        PromotionalOffer(
            id = "offer_comeback_20",
            title = "We Miss You! 20% Off + Free Cold Coffee",
            description = "Special Come-Back treat for our valued Kusum Bakery Junction guests on orders above ₹200.",
            promoCode = "WELCOME20",
            discountPercent = 20,
            maxDiscountInr = 150.0,
            minOrderInr = 200.0,
            isActive = true
        ),
        PromotionalOffer(
            id = "offer_pizza_combo",
            title = "Pizza & Shake Party 15% Combo Offer",
            description = "Flat 15% off on Medium/Large Pizzas paired with any Thick Shake or Mojito.",
            promoCode = "KUSUM15",
            discountPercent = 15,
            maxDiscountInr = 120.0,
            minOrderInr = 300.0,
            isActive = true
        )
    )

    fun defaultDemoCustomers(nowMillis: Long = System.currentTimeMillis()): List<AppUser> = listOf(
        AppUser(
            uid = "cust_active_aarav",
            name = "Aarav Sharma",
            phone = "+919826011223",
            email = "aarav.sharma@example.com",
            role = UserRole.CUSTOMER,
            totalVisits = 4,
            lastVisitAt = nowMillis - TimeUnit.DAYS.toMillis(1),
            loyaltyStamps = 4,
            marketingConsent = true,
            isDemoData = false,
            createdAt = nowMillis - TimeUnit.DAYS.toMillis(45)
        ),
        AppUser(
            uid = "cust_inactive_priya",
            name = "Priya Nair",
            phone = "+919826044556",
            email = "priya.nair@example.com",
            role = UserRole.CUSTOMER,
            totalVisits = 6,
            lastVisitAt = nowMillis - TimeUnit.DAYS.toMillis(26),
            loyaltyStamps = 3,
            marketingConsent = true,
            isDemoData = false,
            createdAt = nowMillis - TimeUnit.DAYS.toMillis(90)
        ),
        AppUser(
            uid = "cust_inactive_rohan",
            name = "Rohan Verma",
            phone = "+919826077889",
            email = "rohan.verma@example.com",
            role = UserRole.CUSTOMER,
            totalVisits = 3,
            lastVisitAt = nowMillis - TimeUnit.DAYS.toMillis(34),
            loyaltyStamps = 2,
            marketingConsent = true,
            isDemoData = false,
            createdAt = nowMillis - TimeUnit.DAYS.toMillis(75)
        ),
        AppUser(
            uid = "cust_optout_neha",
            name = "Neha Gupta",
            phone = "+919826099001",
            email = "neha.gupta@example.com",
            role = UserRole.CUSTOMER,
            totalVisits = 2,
            lastVisitAt = nowMillis - TimeUnit.DAYS.toMillis(29),
            loyaltyStamps = 2,
            marketingConsent = false,
            isDemoData = false,
            createdAt = nowMillis - TimeUnit.DAYS.toMillis(60)
        )
    )

    fun defaultDemoOrders(nowMillis: Long = System.currentTimeMillis()): List<BakeryOrder> {
        val item1 = OrderItemRecord(
            id = "oi_1",
            orderId = "KBJ-DEMO-101",
            customerId = "cust_active_aarav",
            productId = "p_farm_house_pizza",
            productName = "Farm House Pizza (Medium)",
            quantity = 1,
            unitPriceInr = 270.0,
            totalPriceInr = 270.0,
            createdAt = nowMillis - TimeUnit.MINUTES.toMillis(45)
        )
        val item2 = OrderItemRecord(
            id = "oi_2",
            orderId = "KBJ-DEMO-101",
            customerId = "cust_active_aarav",
            productId = "p_cold_coffee_ice_cream",
            productName = "Cold Coffee With Ice Cream (Large)",
            quantity = 1,
            unitPriceInr = 85.0,
            totalPriceInr = 85.0,
            createdAt = nowMillis - TimeUnit.MINUTES.toMillis(45)
        )
        val item3 = OrderItemRecord(
            id = "oi_3",
            orderId = "KBJ-DEMO-102",
            customerId = "cust_active_aarav",
            productId = "p_volcano_burger",
            productName = "Volcano Burger",
            quantity = 2,
            unitPriceInr = 120.0,
            totalPriceInr = 240.0,
            createdAt = nowMillis - TimeUnit.MINUTES.toMillis(15)
        )
        return listOf(
            BakeryOrder(
                id = "KBJ-DEMO-101",
                customerId = "cust_active_aarav",
                customerName = "Aarav Sharma",
                customerPhone = "+919826011223",
                tableId = "TBL-01",
                tableNumber = 1,
                itemsSummary = listOf(item1, item2),
                subtotalInr = 355.0,
                discountInr = 0.0,
                totalAmount = 355.0,
                status = OrderStatus.COMPLETED,
                stampAwarded = true,
                isDemoData = false,
                createdAt = nowMillis - TimeUnit.MINUTES.toMillis(45),
                updatedAt = nowMillis - TimeUnit.MINUTES.toMillis(20)
            ),
            BakeryOrder(
                id = "KBJ-DEMO-102",
                customerId = "cust_active_aarav",
                customerName = "Aarav Sharma",
                customerPhone = "+919826011223",
                tableId = "TBL-03",
                tableNumber = 3,
                itemsSummary = listOf(item3),
                subtotalInr = 240.0,
                discountInr = 0.0,
                totalAmount = 240.0,
                status = OrderStatus.PREPARING,
                stampAwarded = false,
                isDemoData = false,
                createdAt = nowMillis - TimeUnit.MINUTES.toMillis(15),
                updatedAt = nowMillis - TimeUnit.MINUTES.toMillis(10)
            )
        )
    }
}
