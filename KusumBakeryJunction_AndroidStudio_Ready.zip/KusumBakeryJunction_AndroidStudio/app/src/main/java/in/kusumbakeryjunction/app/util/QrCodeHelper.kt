package `in`.kusumbakeryjunction.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.io.File
import java.io.FileOutputStream

object QrCodeHelper {

    fun buildTableQrPayload(tableId: String, tableNumber: Int): String {
        return "kusumbakery://table?tableId=$tableId&tableNumber=$tableNumber"
    }

    fun parseTableIdFromQrPayload(rawPayload: String): String? {
        val trimmed = rawPayload.trim()
        if (trimmed.isEmpty()) return null
        if (trimmed.startsWith("kusumbakery://table")) {
            val query = trimmed.substringAfter("?", "")
            val params = query.split("&").associate {
                val parts = it.split("=")
                parts.getOrNull(0).orEmpty() to parts.getOrNull(1).orEmpty()
            }
            return params["tableId"]?.takeIf { it.isNotBlank() }
        }
        // Fallback: direct table ID such as TBL-01 or T1
        return trimmed
    }

    fun generatePrintableQrBitmap(
        tableNumber: Int,
        tableId: String,
        sizePx: Int = 640
    ): Bitmap {
        val payload = buildTableQrPayload(tableId, tableNumber)
        val hints = mapOf(
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 1
        )
        val bitMatrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val headerHeight = 120
        val footerHeight = 110
        val totalHeight = sizePx + headerHeight + footerHeight

        val bitmap = Bitmap.createBitmap(sizePx, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.parseColor("#FFF8F0"))

        val darkBrown = Color.parseColor("#3E2415")
        val caramel = Color.parseColor("#C87D32")

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = darkBrown
            textSize = 36f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = caramel
            textSize = 26f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        canvas.drawText("KUSUM BAKERY JUNCTION", sizePx / 2f, 52f, titlePaint)
        canvas.drawText("SCAN TO ORDER • TABLE #$tableNumber", sizePx / 2f, 96f, subtitlePaint)

        for (x in 0 until sizePx) {
            for (y in 0 until sizePx) {
                bitmap.setPixel(
                    x,
                    y + headerHeight,
                    if (bitMatrix[x, y]) darkBrown else Color.WHITE
                )
            }
        }

        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = darkBrown
            textSize = 24f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Table ID: $tableId • Bhopal, India", sizePx / 2f, headerHeight + sizePx + 56f, footerPaint)
        return bitmap
    }

    fun shareOrPrintQrBitmap(context: Context, tableNumber: Int, tableId: String) {
        val bitmap = generatePrintableQrBitmap(tableNumber, tableId)
        val dir = File(context.cacheDir, "qr_codes").apply { mkdirs() }
        val file = File(dir, "KusumBakery_Table_${tableNumber}_QR.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(
                Intent.EXTRA_TEXT,
                "Kusum Bakery Junction - Printable QR Code for Table #$tableNumber ($tableId)"
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Print or Download Table #$tableNumber QR"))
    }
}
