package `in`.kusumbakeryjunction.app.util

import `in`.kusumbakeryjunction.app.data.model.*
import java.util.concurrent.TimeUnit

/**
 * Pure domain logic engine for Kusum Bakery Junction.
 * Powers both the Android ViewModel and the automated JUnit 4 verification suite.
 */
object BusinessLogicEngine {

    /**
     * Calculates cart subtotal, discount, and final payable amount in ₹.
     */
    fun calculateCartTotals(cartItems: List<CartItem>): Triple<Double, Double, Double> {
        val rawSubtotal = cartItems.sumOf { it.product.priceInr * it.quantity }
        val effectiveTotal = cartItems.sumOf { it.lineTotalInr }
        val discount = (rawSubtotal - effectiveTotal).coerceAtLeast(0.0)
        return Triple(rawSubtotal, discount, effectiveTotal)
    }

    /**
     * Validates a scanned Table ID against the active tables list.
     */
    fun validateTableForOrder(tableId: String, tables: List<BakeryTable>): BakeryTable? {
        return tables.firstOrNull {
            it.isActive && it.id.equals(tableId.trim(), ignoreCase = true)
        }
    }

    /**
     * Processes adding 1 loyalty stamp to a 5-slot card:
     * - Blocks duplicate stamps for the same orderId.
     * - Unlocks a unique reward code when reaching 5 stamps and resets currentStamps to 0.
     */
    fun applyOneTapStamp(
        card: LoyaltyCard,
        orderId: String,
        existingStampHistory: List<StampHistoryRecord>,
        staffUser: AppUser,
        rewardTitle: String,
        nowMillis: Long = System.currentTimeMillis()
    ): Result<Triple<LoyaltyCard, StampHistoryRecord, CustomerReward?>> = runCatching {
        require(staffUser.role == UserRole.STAFF || staffUser.role == UserRole.OWNER) {
            "Only Staff or Owner can add loyalty stamps."
        }
        if (orderId.isNotBlank()) {
            val duplicate = existingStampHistory.any {
                it.customerId == card.customerId && it.orderId.equals(orderId, ignoreCase = true)
            } || card.lastStampOrderId.equals(orderId, ignoreCase = true)
            require(!duplicate) {
                "Duplicate Stamp Blocked: Order $orderId has already earned a stamp."
            }
        }

        val nextSlot = card.currentStamps + 1
        val unlocked = nextSlot >= 5
        val newCurrentStamps = if (unlocked) 0 else nextSlot

        val updatedCard = card.copy(
            currentStamps = newCurrentStamps,
            totalStampsEarned = card.totalStampsEarned + 1,
            totalRewardsUnlocked = if (unlocked) card.totalRewardsUnlocked + 1 else card.totalRewardsUnlocked,
            lastStampOrderId = orderId.ifBlank { card.lastStampOrderId },
            updatedAt = nowMillis
        )

        val history = StampHistoryRecord(
            id = "STAMP_${card.customerId}_${nowMillis}",
            customerId = card.customerId,
            customerName = card.customerName,
            orderId = orderId.ifBlank { "ONE_TAP_COUNTER" },
            stampNumberInCycle = nextSlot,
            addedByUid = staffUser.uid,
            addedByName = staffUser.name,
            note = if (unlocked) "5th Stamp Added — Reward Unlocked!" else "Stamp #$nextSlot/5 added",
            createdAt = nowMillis
        )

        val reward = if (unlocked) {
            CustomerReward(
                id = "RWD_${nowMillis}",
                customerId = card.customerId,
                customerName = card.customerName,
                customerPhone = card.customerPhone,
                rewardTitle = rewardTitle,
                rewardCode = Formatters.generateRewardCode(),
                isRedeemed = false,
                unlockedAt = nowMillis
            )
        } else null

        Triple(updatedCard, history, reward)
    }

    /**
     * Redeems a reward code and strictly blocks duplicate redemption.
     */
    fun redeemReward(
        rewardCode: String,
        rewards: List<CustomerReward>,
        staffUser: AppUser,
        nowMillis: Long = System.currentTimeMillis()
    ): Result<CustomerReward> = runCatching {
        require(staffUser.role == UserRole.STAFF || staffUser.role == UserRole.OWNER) {
            "Only Staff or Owner can redeem customer rewards."
        }
        val target = rewards.firstOrNull {
            it.rewardCode.equals(rewardCode.trim(), ignoreCase = true)
        } ?: throw NoSuchElementException("Invalid Reward Code: $rewardCode")

        if (target.isRedeemed) {
            throw IllegalStateException("Duplicate Redemption Blocked: Reward ${target.rewardCode} is already redeemed.")
        }

        target.copy(
            isRedeemed = true,
            redeemedAt = nowMillis,
            redeemedByStaffUid = staffUser.uid
        )
    }

    /**
     * Filters customers who have not visited for >= thresholdDays (default 21 days).
     * Separates customers into all inactive (>=21 days) and contactable (marketingConsent == true).
     */
    fun findComeBackCustomers(
        users: List<AppUser>,
        thresholdDays: Int = 21,
        onlyOptedIn: Boolean = false,
        nowMillis: Long = System.currentTimeMillis()
    ): List<AppUser> {
        return users.filter { user ->
            user.role == UserRole.CUSTOMER &&
                Formatters.daysSinceIst(user.lastVisitAt, nowMillis) >= thresholdDays &&
                (!onlyOptedIn || user.marketingConsent)
        }.sortedBy { it.lastVisitAt }
    }

    /**
     * Computes all 11 Owner Admin Dashboard KPIs for the selected DateFilterRange in Asia/Kolkata timezone.
     */
    fun computeOwnerDashboardMetrics(
        filterRange: DateFilterRange,
        customStartMillis: Long = 0L,
        customEndMillis: Long = System.currentTimeMillis(),
        orders: List<BakeryOrder>,
        customers: List<AppUser>,
        offerHistory: List<OfferDeliveryRecord>,
        rewards: List<CustomerReward>,
        nowMillis: Long = System.currentTimeMillis()
    ): OwnerDashboardMetrics {
        val todayStart = Formatters.startOfTodayIst(nowMillis)
        val thirtyDaysAgoStart = Formatters.startOfDaysAgoIst(30, nowMillis)

        val rangeStart = when (filterRange) {
            DateFilterRange.TODAY -> todayStart
            DateFilterRange.LAST_7_DAYS -> Formatters.startOfDaysAgoIst(7, nowMillis)
            DateFilterRange.LAST_30_DAYS -> thirtyDaysAgoStart
            DateFilterRange.CUSTOM -> if (customStartMillis > 0L) customStartMillis else Formatters.startOfDaysAgoIst(14, nowMillis)
        }
        val rangeEnd = if (filterRange == DateFilterRange.CUSTOM && customEndMillis > 0L) {
            customEndMillis
        } else {
            nowMillis + TimeUnit.HOURS.toMillis(1)
        }

        val validOrders = orders.filter { it.status != OrderStatus.CANCELLED }
        val todayOrders = validOrders.filter { it.createdAt >= todayStart }
        val monthlyOrders = validOrders.filter { it.createdAt >= thirtyDaysAgoStart }
        val filteredOrders = validOrders.filter { it.createdAt in rangeStart..rangeEnd }

        val pendingCount = orders.count {
            it.status in listOf(OrderStatus.PENDING, OrderStatus.ACCEPTED, OrderStatus.PREPARING, OrderStatus.READY)
        }

        val onlyCustomers = customers.filter { it.role == UserRole.CUSTOMER }
        val totalCust = onlyCustomers.size
        val newCust = onlyCustomers.count { it.createdAt >= rangeStart }
        val repeatCust = onlyCustomers.count { it.totalVisits > 1 }
        val repeatPct = if (totalCust > 0) (repeatCust.toDouble() * 100.0 / totalCust.toDouble()) else 0.0

        // Top-selling products aggregation across filtered orders
        val productCounts = mutableMapOf<String, Int>()
        filteredOrders.flatMap { it.itemsSummary }.forEach { item ->
            productCounts[item.productName] = (productCounts[item.productName] ?: 0) + item.quantity
        }
        val topProducts = productCounts.entries
            .sortedByDescending { it.value }
            .take(5)
            .map { it.key to it.value }

        val filteredOffers = offerHistory.filter { it.sentAt in rangeStart..rangeEnd }
        val offersSent = filteredOffers.size
        val returnedAfterOffer = filteredOffers.count { it.customerReturned || it.deliveryStatus == "REDEEMED" }
        val redeemedRewardsCount = rewards.count { it.isRedeemed && it.redeemedAt in rangeStart..rangeEnd }

        return OwnerDashboardMetrics(
            filterRange = filterRange,
            filteredOrdersCount = filteredOrders.size,
            filteredSalesInr = filteredOrders.sumOf { it.totalAmount },
            todayOrdersCount = todayOrders.size,
            todaySalesInr = todayOrders.sumOf { it.totalAmount },
            monthlySalesInr = monthlyOrders.sumOf { it.totalAmount },
            pendingOrdersCount = pendingCount,
            totalCustomersCount = totalCust,
            newCustomersCount = newCust,
            repeatCustomerPercentage = Math.round(repeatPct * 10.0) / 10.0,
            topSellingProducts = topProducts,
            offersSentCount = offersSent,
            customersReturnedAfterOfferCount = returnedAfterOffer,
            loyaltyRewardsRedeemedCount = redeemedRewardsCount
        )
    }
}
