package `in`.kusumbakeryjunction.app.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.TimeUnit

object Formatters {
    val IST_TIMEZONE: TimeZone = TimeZone.getTimeZone("Asia/Kolkata")
    private val INDIA_LOCALE = Locale("en", "IN")

    fun formatInr(amount: Double): String {
        val formatter = NumberFormat.getCurrencyInstance(INDIA_LOCALE)
        formatter.maximumFractionDigits = if (amount % 1.0 == 0.0) 0 else 2
        return formatter.format(amount)
    }

    fun formatIstDateTime(timestampMillis: Long): String {
        if (timestampMillis <= 0L) return "Never"
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a 'IST'", INDIA_LOCALE)
        sdf.timeZone = IST_TIMEZONE
        return sdf.format(Date(timestampMillis))
    }

    fun formatIstDate(timestampMillis: Long): String {
        if (timestampMillis <= 0L) return "Never"
        val sdf = SimpleDateFormat("dd MMM yyyy", INDIA_LOCALE)
        sdf.timeZone = IST_TIMEZONE
        return sdf.format(Date(timestampMillis))
    }

    fun startOfTodayIst(nowMillis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance(IST_TIMEZONE, INDIA_LOCALE)
        cal.timeInMillis = nowMillis
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun startOfDaysAgoIst(daysAgo: Int, nowMillis: Long = System.currentTimeMillis()): Long {
        val todayStart = startOfTodayIst(nowMillis)
        return todayStart - TimeUnit.DAYS.toMillis(daysAgo.toLong())
    }

    fun daysSinceIst(pastMillis: Long, nowMillis: Long = System.currentTimeMillis()): Long {
        if (pastMillis <= 0L) return 999L
        val diff = (nowMillis - pastMillis).coerceAtLeast(0L)
        return TimeUnit.MILLISECONDS.toDays(diff)
    }

    fun isValidIndianPhone(rawPhone: String): Boolean {
        val digits = rawPhone.filter { it.isDigit() }
        val normalized = when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            else -> digits
        }
        return normalized.length == 10 && normalized.first() in listOf('6', '7', '8', '9')
    }

    fun normalizeIndianPhone(rawPhone: String): String {
        val digits = rawPhone.filter { it.isDigit() }
        val tenDigits = when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            digits.length >= 10 -> digits.takeLast(10)
            else -> digits
        }
        return "+91$tenDigits"
    }

    fun generateOrderId(nowMillis: Long = System.currentTimeMillis()): String {
        val sdf = SimpleDateFormat("yyMMdd", INDIA_LOCALE).apply { timeZone = IST_TIMEZONE }
        val datePart = sdf.format(Date(nowMillis))
        val randomSuffix = UUID.randomUUID().toString().uppercase().replace("-", "").take(5)
        return "KBJ-$datePart-$randomSuffix"
    }

    fun generateRewardCode(): String {
        val token = UUID.randomUUID().toString().uppercase().replace("-", "").take(6)
        return "KBJ-RWD-$token"
    }
}
