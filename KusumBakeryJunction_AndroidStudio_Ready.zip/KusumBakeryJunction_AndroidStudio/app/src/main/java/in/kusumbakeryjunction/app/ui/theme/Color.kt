package `in`.kusumbakeryjunction.app.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Cream & Chocolate Brown Bakery Palette
val BakeryCreamBg = Color(0xFFFFF8F0)
val BakeryWarmSurface = Color(0xFFFDF3E7)
val BakeryLatteCard = Color(0xFFF5E6D3)
val BakeryChocolateDark = Color(0xFF3E2415)
val BakeryChocolatePrimary = Color(0xFF5C3317)
val BakeryCaramelSecondary = Color(0xFFC87D32)
val BakeryGoldAccent = Color(0xFFE5A93C)
val BakeryCinnamonMuted = Color(0xFF8C6246)
val BakeryDivider = Color(0xFFE6D2B8)

// Semantic Status Colors
val StatusPendingBg = Color(0xFFFFF3CD)
val StatusPendingText = Color(0xFF856404)
val StatusAcceptedBg = Color(0xFFD1ECF1)
val StatusAcceptedText = Color(0xFF0C5460)
val StatusPreparingBg = Color(0xFFE2D9F3)
val StatusPreparingText = Color(0xFF432874)
val StatusReadyBg = Color(0xFFD4EDDA)
val StatusReadyText = Color(0xFF155724)
val StatusCompletedBg = Color(0xFFE8F5E9)
val StatusCompletedText = Color(0xFF1B5E20)
val StatusErrorRed = Color(0xFFB83B2B)
val WhatsAppGreen = Color(0xFF25D366)
