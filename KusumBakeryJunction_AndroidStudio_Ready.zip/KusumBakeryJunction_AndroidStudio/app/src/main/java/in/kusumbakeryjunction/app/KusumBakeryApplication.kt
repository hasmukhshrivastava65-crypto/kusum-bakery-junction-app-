package `in`.kusumbakeryjunction.app

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import java.util.TimeZone

class KusumBakeryApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Enforce Asia/Kolkata (IST) timezone across all business timestamps and date filters
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Kolkata"))

        // Initialize Firebase with offline persistence enabled for resilient bakery operations
        FirebaseApp.initializeApp(this)
        val settings = FirebaseFirestoreSettings.Builder()
            .setLocalCacheSettings(
                PersistentCacheSettings.newBuilder()
                    .setSizeBytes(100L * 1024L * 1024L) // 100 MB offline cache
                    .build()
            )
            .build()
        FirebaseFirestore.getInstance().firestoreSettings = settings
    }
}
