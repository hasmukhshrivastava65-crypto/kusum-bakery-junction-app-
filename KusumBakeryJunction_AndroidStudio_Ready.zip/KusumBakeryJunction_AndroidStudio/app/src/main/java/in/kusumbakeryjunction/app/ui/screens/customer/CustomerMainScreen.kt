package `in`.kusumbakeryjunction.app.ui.screens.customer

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import `in`.kusumbakeryjunction.app.data.model.*
import `in`.kusumbakeryjunction.app.ui.components.OrderStatusBadge
import `in`.kusumbakeryjunction.app.ui.theme.*
import `in`.kusumbakeryjunction.app.util.BusinessLogicEngine
import `in`.kusumbakeryjunction.app.util.Formatters
import `in`.kusumbakeryjunction.app.viewmodel.KusumUiState
import `in`.kusumbakeryjunction.app.viewmodel.KusumViewModel

private enum class CustomerTab(val label: String) {
    QR_MENU("QR Order"),
    LOYALTY("5-Stamp Card"),
    REWARDS("Rewards"),
    OFFERS("Offers"),
    PROFILE("Profile")
}

@Composable
fun CustomerMainScreen(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    var selectedTab by remember { mutableStateOf(CustomerTab.QR_MENU) }

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = BakeryWarmSurface) {
                CustomerTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {
                            val icon = when (tab) {
                                CustomerTab.QR_MENU -> Icons.Default.QrCodeScanner
                                CustomerTab.LOYALTY -> Icons.Default.Stars
                                CustomerTab.REWARDS -> Icons.Default.CardGiftcard
                                CustomerTab.OFFERS -> Icons.Default.LocalOffer
                                CustomerTab.PROFILE -> Icons.Default.Person
                            }
                            Icon(icon, contentDescription = tab.label)
                        },
                        label = { Text(tab.label, maxLines = 1) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BakeryCreamBg)
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                CustomerTab.QR_MENU -> CustomerQrOrderingSection(uiState, viewModel)
                CustomerTab.LOYALTY -> CustomerLoyaltyStampSection(uiState)
                CustomerTab.REWARDS -> CustomerRewardsAndReviewsSection(uiState, viewModel)
                CustomerTab.OFFERS -> CustomerComeBackOffersSection(uiState)
                CustomerTab.PROFILE -> CustomerProfileSection(uiState, viewModel)
            }
        }
    }
}

// ============================================================================
// Section A: QR Table Ordering, Menu, Cart & Live Order Status
// ============================================================================
@Composable
private fun CustomerQrOrderingSection(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    val user = uiState.currentUser ?: return
    var customerName by remember(user.name) { mutableStateOf(user.name) }
    var customerPhone by remember(user.phone) { mutableStateOf(user.phone) }
    var manualQrInput by remember { mutableStateOf("") }
    var showQrDialog by remember { mutableStateOf(false) }

    val filteredProducts = remember(uiState.products, uiState.selectedCategoryId) {
        if (uiState.selectedCategoryId == "ALL") {
            uiState.products
        } else {
            uiState.products.filter { it.categoryId == uiState.selectedCategoryId }
        }
    }

    val customerOrders = remember(uiState.orders, user.uid) {
        uiState.orders.filter { it.customerId == user.uid }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Table QR Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BakeryLatteCard),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode2,
                        contentDescription = null,
                        tint = BakeryChocolateDark,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = uiState.scannedTable?.let { "Ordering for Table #${it.tableNumber} (${it.id})" }
                                ?: "No Table QR Scanned Yet",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Scan the QR stand on your table to route your order directly to our barista & kitchen.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(
                        onClick = { showQrDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                    ) {
                        Text("Scan Table QR")
                    }
                }
            }
        }

        // Category Filter Pills
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = uiState.selectedCategoryId == "ALL",
                        onClick = { viewModel.selectCategory("ALL") },
                        label = { Text("All Bakery Items") }
                    )
                }
                items(uiState.categories) { cat ->
                    FilterChip(
                        selected = uiState.selectedCategoryId == cat.id,
                        onClick = { viewModel.selectCategory(cat.id) },
                        label = { Text("${cat.iconEmoji} ${cat.name}") }
                    )
                }
            }
        }

        // Menu Product Cards
        items(filteredProducts, key = { it.id }) { product ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = product.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            if (product.isDemoData) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "DEMO",
                                    color = BakeryCaramelSecondary,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = product.description,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = Formatters.formatInr(product.effectivePriceInr),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = BakeryChocolatePrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            if (product.discountPercent > 0) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = Formatters.formatInr(product.priceInr),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        textDecoration = TextDecoration.LineThrough
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${product.discountPercent}% OFF",
                                    color = StatusCompletedText,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = { viewModel.addToCart(product) },
                        enabled = product.isAvailable,
                        colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                    ) {
                        Text(if (product.isAvailable) "+ Add" else "Sold Out")
                    }
                }
            }
        }

        // Cart & Checkout Box
        if (uiState.cart.isNotEmpty()) {
            item {
                val (subtotal, discount, total) = BusinessLogicEngine.calculateCartTotals(uiState.cart)
                Card(
                    colors = CardDefaults.cardColors(containerColor = BakeryWarmSurface),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, BakeryChocolatePrimary, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Your Table Order Cart (${uiState.scannedTable?.id ?: "Select Table"})",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        uiState.cart.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item.product.name,
                                    modifier = Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                                )
                                OutlinedIconButton(
                                    onClick = { viewModel.updateCartQuantity(item.product.id, -1) },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Text("-")
                                }
                                Text(
                                    text = "${item.quantity}",
                                    modifier = Modifier.padding(horizontal = 10.dp),
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedIconButton(
                                    onClick = { viewModel.updateCartQuantity(item.product.id, +1) },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Text("+")
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = Formatters.formatInr(item.lineTotalInr),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                            Text("Subtotal")
                            Text(Formatters.formatInr(subtotal))
                        }
                        if (discount > 0) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text("Offer Discount", color = StatusCompletedText)
                                Text("- ${Formatters.formatInr(discount)}", color = StatusCompletedText)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                            Text("Total Payable (₹)", fontWeight = FontWeight.Bold)
                            Text(Formatters.formatInr(total), fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Your Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customerPhone,
                            onValueChange = { customerPhone = it },
                            label = { Text("Phone Number (+91)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.placeTableOrder(customerName, customerPhone) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolateDark)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Place Table Order (${Formatters.formatInr(total)})")
                        }
                    }
                }
            }
        }

        // Active & Past Orders Tracker (Pending -> Accepted -> Preparing -> Ready -> Completed)
        if (customerOrders.isNotEmpty()) {
            item {
                Text(
                    text = "Live Order Status & History",
                    style = MaterialTheme.typography.titleLarge
                )
            }
            items(customerOrders, key = { it.id }) { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${order.id} • Table #${order.tableNumber}",
                                fontWeight = FontWeight.Bold
                            )
                            OrderStatusBadge(order.status)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        order.itemsSummary.forEach { item ->
                            Text(
                                text = "• ${item.quantity}x ${item.productName} (${Formatters.formatInr(item.totalPriceInr)})",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = Formatters.formatIstDateTime(order.createdAt),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "Total: ${Formatters.formatInr(order.totalAmount)}",
                                fontWeight = FontWeight.Bold,
                                color = BakeryChocolatePrimary
                            )
                        }
                    }
                }
            }
        }
    }

    if (showQrDialog) {
        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            title = { Text("Scan or Select Table QR Code") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tap a table QR below or enter a QR payload:")
                    uiState.tables.take(6).forEach { tbl ->
                        OutlinedButton(
                            onClick = {
                                viewModel.onQrPayloadScanned(tbl.qrPayload)
                                showQrDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${tbl.id} — ${tbl.label} (${tbl.seats} Seats)")
                        }
                    }
                    OutlinedTextField(
                        value = manualQrInput,
                        onValueChange = { manualQrInput = it },
                        label = { Text("Or enter Table ID (e.g. TBL-02)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                if (manualQrInput.isNotBlank()) {
                    TextButton(onClick = {
                        viewModel.onQrPayloadScanned(manualQrInput)
                        showQrDialog = false
                    }) {
                        Text("Validate Table ID")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showQrDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

// ============================================================================
// Section B: 5-Slot Loyalty Stamp Card & Complete Stamp History
// ============================================================================
@Composable
private fun CustomerLoyaltyStampSection(uiState: KusumUiState) {
    val user = uiState.currentUser ?: return
    val card = uiState.loyaltyCards[user.uid] ?: LoyaltyCard(
        customerId = user.uid,
        customerName = user.name,
        customerPhone = user.phone,
        currentStamps = user.loyaltyStamps
    )
    val myHistory = uiState.stampHistory.filter { it.customerId == user.uid }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BakeryChocolateDark),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "KUSUM BAKERY LOYALTY CARD",
                        color = BakeryGoldAccent,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${card.currentStamps} of 5 Stamps Collected",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Reward after 5 stamps: ${uiState.appSettings.freeRewardTitle}",
                        color = Color(0xFFFFE5C4),
                        style = MaterialTheme.typography.bodySmall
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // 5 Visual Stamp Slots
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        (1..5).forEach { slot ->
                            val isFilled = slot <= card.currentStamps
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(if (isFilled) BakeryGoldAccent else Color(0xFF5A3A25))
                                    .border(2.dp, BakeryGoldAccent, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isFilled) {
                                    Icon(
                                        imageVector = Icons.Default.BakeryDining,
                                        contentDescription = "Stamped Slot $slot",
                                        tint = BakeryChocolateDark
                                    )
                                } else {
                                    Text(
                                        text = "#$slot",
                                        color = Color(0xFFFFE5C4),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Show your phone number (${user.phone}) to Staff at checkout to add 1 stamp per completed purchase.",
                        color = Color(0xFFFFE5C4),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            Text(
                text = "Complete Stamp History (${myHistory.size})",
                style = MaterialTheme.typography.titleLarge
            )
        }

        if (myHistory.isEmpty()) {
            item {
                Text(
                    text = "No stamps recorded yet. Place an order to earn your first stamp!",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            items(myHistory, key = { it.id }) { rec ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = BakeryCaramelSecondary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rec.note, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Order: ${rec.orderId} • Verified by: ${rec.addedByName}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = Formatters.formatIstDateTime(rec.createdAt),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// Section C: Unlocked Rewards & Configurable Google Business Review Button
// ============================================================================
@Composable
private fun CustomerRewardsAndReviewsSection(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    val context = LocalContext.current
    val user = uiState.currentUser ?: return
    val myRewards = uiState.rewards.filter { it.customerId == user.uid }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BakeryLatteCard),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Enjoyed Kusum Bakery Junction?",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Your genuine feedback on Google Maps helps our Bhopal bakery grow! (Opens our official Google Business Profile review page — never auto-posts).",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val intent = Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse(uiState.appSettings.googleReviewUrl)
                            )
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BakeryChocolatePrimary)
                    ) {
                        Icon(Icons.Default.StarRate, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Write a Google Review")
                    }
                }
            }
        }

        item {
            Text(
                text = "Your Loyalty Rewards (${myRewards.size})",
                style = MaterialTheme.typography.titleLarge
            )
        }

        if (myRewards.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("No rewards unlocked yet.")
                        Text(
                            "Collect 5 stamps on your Loyalty Card to unlock: ${uiState.appSettings.freeRewardTitle}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        } else {
            items(myRewards, key = { it.id }) { reward ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(reward.rewardTitle, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Unique Reward Code: ${reward.rewardCode}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = BakeryChocolatePrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        if (reward.isRedeemed) {
                            Text(
                                text = "REDEEMED on ${Formatters.formatIstDateTime(reward.redeemedAt)}",
                                color = StatusCompletedText,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else {
                            Button(
                                onClick = { viewModel.redeemCustomerRewardCode(reward.rewardCode) },
                                colors = ButtonDefaults.buttonColors(containerColor = BakeryCaramelSecondary)
                            ) {
                                Text("Redeem Reward at Counter")
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// Section D: Customer Come-Back & Special Promotional Offers
// ============================================================================
@Composable
private fun CustomerComeBackOffersSection(uiState: KusumUiState) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Active Bakery Offers & Come-Back Specials",
                style = MaterialTheme.typography.titleLarge
            )
        }

        items(uiState.offers.filter { it.isActive }, key = { it.id }) { offer ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(offer.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(offer.description, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = BakeryLatteCard,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "PROMO CODE: ${offer.promoCode} • ${offer.discountPercent}% OFF (Up to ₹${offer.maxDiscountInr.toInt()})",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            fontWeight = FontWeight.Bold,
                            color = BakeryChocolateDark
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// Section E: Customer Profile & Marketing Consent Preferences
// ============================================================================
@Composable
private fun CustomerProfileSection(
    uiState: KusumUiState,
    viewModel: KusumViewModel
) {
    val user = uiState.currentUser ?: return
    val myOrders = uiState.orders.filter { it.customerId == user.uid }
    val myRewards = uiState.rewards.filter { it.customerId == user.uid && !it.isRedeemed }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(user.name, style = MaterialTheme.typography.headlineMedium)
                    Text("Phone: ${user.phone}", style = MaterialTheme.typography.bodyLarge)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Visits", style = MaterialTheme.typography.bodySmall)
                            Text("${user.totalVisits}", style = MaterialTheme.typography.titleLarge)
                        }
                        Column {
                            Text("Active Stamps", style = MaterialTheme.typography.bodySmall)
                            Text("${user.loyaltyStamps} / 5", style = MaterialTheme.typography.titleLarge)
                        }
                        Column {
                            Text("Available Rewards", style = MaterialTheme.typography.bodySmall)
                            Text("${myRewards.size}", style = MaterialTheme.typography.titleLarge)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("WhatsApp Marketing & Come-Back Offers", fontWeight = FontWeight.Bold)
                            Text(
                                "Only send me promotional offers when I opt in.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = user.marketingConsent,
                            onCheckedChange = { viewModel.updateCustomerMarketingConsent(it) }
                        )
                    }
                }
            }
        }

        item {
            Text("Order History (${myOrders.size})", style = MaterialTheme.typography.titleLarge)
        }

        items(myOrders, key = { it.id }) { order ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("${order.id} (Table #${order.tableNumber})", fontWeight = FontWeight.Bold)
                        Text(Formatters.formatIstDateTime(order.createdAt), style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(Formatters.formatInr(order.totalAmount), fontWeight = FontWeight.Bold)
                        OrderStatusBadge(order.status)
                    }
                }
            }
        }
    }
}
