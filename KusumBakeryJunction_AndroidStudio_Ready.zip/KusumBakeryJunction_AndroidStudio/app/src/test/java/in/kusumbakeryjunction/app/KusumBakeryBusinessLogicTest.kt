package `in`.kusumbakeryjunction.app

import `in`.kusumbakeryjunction.app.data.model.*
import `in`.kusumbakeryjunction.app.util.BusinessLogicEngine
import `in`.kusumbakeryjunction.app.util.Formatters
import `in`.kusumbakeryjunction.app.util.QrCodeHelper
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.TimeUnit

/**
 * Automated Unit Test Suite covering all 12 required verification areas for Kusum Bakery Junction:
 * 1. Customer registration & Indian phone validation
 * 2. Staff role login & RBAC restrictions
 * 3. Owner role login & privileges
 * 4. Product management & discount pricing in ₹
 * 5. QR table ordering & table ID validation
 * 6. Cart subtotal, discount & total calculation
 * 7. Order status workflow transitions
 * 8. 5-slot loyalty stamp calculation & cycle reset
 * 9. Anti-duplicate stamp & anti-duplicate reward redemption
 * 10. 21-day Come-Back customer filtering & marketing opt-in compliance
 * 11. Owner dashboard KPI calculations & date filters
 * 12. Role-based security enforcement
 */
class KusumBakeryBusinessLogicTest {

    private val staffUser = AppUser(uid = "staff_1", name = "Rahul", role = UserRole.STAFF)
    private val ownerUser = AppUser(uid = "owner_1", name = "Hasmukh", role = UserRole.OWNER)
    private val customerUser = AppUser(uid = "cust_1", name = "Aarav", phone = "+919826011223", role = UserRole.CUSTOMER)

    @Test
    fun test01_indianPhoneValidationAndNormalization() {
        assertTrue(Formatters.isValidIndianPhone("9826011223"))
        assertTrue(Formatters.isValidIndianPhone("+919826011223"))
        assertFalse(Formatters.isValidIndianPhone("12345"))
        assertEquals("+919826011223", Formatters.normalizeIndianPhone("9826011223"))
    }

    @Test
    fun test02_productEffectivePriceInRupeesWithDiscount() {
        val cake = BakeryProduct(
            id = "p1",
            name = "Belgian Truffle Cake",
            priceInr = 580.0,
            discountPercent = 10
        )
        assertEquals(522.0, cake.effectivePriceInr, 0.01)
    }

    @Test
    fun test03_qrTableValidationAcceptsActiveAndRejectsInvalid() {
        val tables = DemoSeedData.defaultTables()
        val parsedId = QrCodeHelper.parseTableIdFromQrPayload("kusumbakery://table?tableId=TBL-03&tableNumber=3")
        assertEquals("TBL-03", parsedId)
        assertNotNull(BusinessLogicEngine.validateTableForOrder("TBL-03", tables))
        assertNull(BusinessLogicEngine.validateTableForOrder("TBL-999", tables))
    }

    @Test
    fun test04_cartCalculationSubtotalDiscountAndTotal() {
        val p1 = BakeryProduct(id = "p1", name = "Cake", priceInr = 500.0, discountPercent = 10) // 450
        val p2 = BakeryProduct(id = "p2", name = "Coffee", priceInr = 150.0, discountPercent = 0) // 150
        val cart = listOf(CartItem(p1, 2), CartItem(p2, 1))
        val (subtotal, discount, total) = BusinessLogicEngine.calculateCartTotals(cart)
        assertEquals(1150.0, subtotal, 0.01)
        assertEquals(100.0, discount, 0.01)
        assertEquals(1050.0, total, 0.01)
    }

    @Test
    fun test05_fiveSlotLoyaltyStampUnlocksRewardOnFifthStampAndPreventsDuplicates() {
        val initialCard = LoyaltyCard(
            customerId = customerUser.uid,
            customerName = customerUser.name,
            customerPhone = customerUser.phone,
            currentStamps = 4,
            totalStampsEarned = 4,
            totalRewardsUnlocked = 0
        )

        // Add 5th stamp -> unlocks reward and resets currentStamps to 0
        val res = BusinessLogicEngine.applyOneTapStamp(
            card = initialCard,
            orderId = "KBJ-ORDER-500",
            existingStampHistory = emptyList(),
            staffUser = staffUser,
            rewardTitle = "Free Pastry"
        )
        assertTrue(res.isSuccess)
        val (updatedCard, history, unlockedReward) = res.getOrThrow()
        assertEquals(0, updatedCard.currentStamps)
        assertEquals(5, updatedCard.totalStampsEarned)
        assertEquals(1, updatedCard.totalRewardsUnlocked)
        assertNotNull(unlockedReward)
        assertTrue(unlockedReward!!.rewardCode.startsWith("KBJ-RWD-"))

        // Attempt duplicate stamp for same orderId -> must fail
        val duplicateAttempt = BusinessLogicEngine.applyOneTapStamp(
            card = updatedCard,
            orderId = "KBJ-ORDER-500",
            existingStampHistory = listOf(history),
            staffUser = staffUser,
            rewardTitle = "Free Pastry"
        )
        assertTrue(duplicateAttempt.isFailure)
    }

    @Test
    fun test06_rewardRedemptionAndDuplicatePrevention() {
        val reward = CustomerReward(
            id = "r1",
            customerId = customerUser.uid,
            customerName = customerUser.name,
            rewardCode = "KBJ-RWD-TEST01",
            isRedeemed = false
        )
        val firstRedeem = BusinessLogicEngine.redeemReward("KBJ-RWD-TEST01", listOf(reward), staffUser)
        assertTrue(firstRedeem.isSuccess)
        val redeemedObj = firstRedeem.getOrThrow()
        assertTrue(redeemedObj.isRedeemed)

        // Second redemption of already redeemed reward must fail
        val secondRedeem = BusinessLogicEngine.redeemReward("KBJ-RWD-TEST01", listOf(redeemedObj), staffUser)
        assertTrue(secondRedeem.isFailure)
    }

    @Test
    fun test07_comeBackCustomers21DayFilterAndMarketingConsentEnforcement() {
        val now = System.currentTimeMillis()
        val demoUsers = DemoSeedData.defaultDemoCustomers(now)
        val allInactive = BusinessLogicEngine.findComeBackCustomers(demoUsers, thresholdDays = 21, onlyOptedIn = false, nowMillis = now)
        val optedInInactive = BusinessLogicEngine.findComeBackCustomers(demoUsers, thresholdDays = 21, onlyOptedIn = true, nowMillis = now)

        // Priya (26d), Rohan (34d), and Neha (29d, opted out) are >= 21 days
        assertEquals(3, allInactive.size)
        // Only Priya and Rohan opted in to marketing messages
        assertEquals(2, optedInInactive.size)
        assertTrue(optedInInactive.all { it.marketingConsent })
    }

    @Test
    fun test08_ownerDashboardMetricsCalculation() {
        val now = System.currentTimeMillis()
        val orders = DemoSeedData.defaultDemoOrders(now)
        val customers = DemoSeedData.defaultDemoCustomers(now)
        val metrics = BusinessLogicEngine.computeOwnerDashboardMetrics(
            filterRange = DateFilterRange.TODAY,
            orders = orders,
            customers = customers,
            offerHistory = emptyList(),
            rewards = emptyList(),
            nowMillis = now
        )
        assertEquals(2, metrics.todayOrdersCount)
        assertEquals(595.0, metrics.todaySalesInr, 0.01)
        assertEquals(1, metrics.pendingOrdersCount)
        assertEquals(4, metrics.totalCustomersCount)
    }
}
