# Kusum Bakery Junction Android project

Package: `in.kusumbakeryjunction.app`

## Build APK
1. Install Android Studio (Ladybug or newer) and Android SDK Platform 34.
2. Open this folder (`KusumBakeryJunction_AndroidStudio`) in Android Studio.
3. Allow Gradle sync and install any prompted SDK/build tools.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

The Firebase configuration is placed at `app/google-services.json`. The debug build uses the same application ID registered in Firebase so Google Services configuration can match.

Before using live customer data, configure Firebase Authentication providers and deploy/review the Firestore and Storage security rules. Phone OTP / Google sign-in may also require SHA-1/SHA-256 fingerprints in Firebase Console.

Note: this is a prepared Android Studio project, not a compiled APK. A compatible Android SDK/Gradle build environment is required to compile it.
